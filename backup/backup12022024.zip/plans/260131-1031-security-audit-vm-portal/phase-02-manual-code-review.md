# Phase 2: Manual Code Review - Critical Security Paths

## Context
- Parent: [plan.md](plan.md)
- Depends on: [Phase 1](phase-01-automated-scanning.md)

## Overview
| Field | Value |
|-------|-------|
| Date | 2026-01-31 |
| Priority | P1 |
| Effort | 4-6 hours |
| Status | pending |

Deep manual review of authentication, authorization, input validation, and API security.

## Focus Areas

### 1. Authentication (1-1.5h)
**Files to review:**
- `backend/app/core/security.py` - JWT, password hashing
- `backend/app/api/auth_endpoints.py` - Login, register, refresh
- `backend/app/dependencies.py` - Token validation

**Checklist:**
- [ ] JWT secret strength and algorithm (HS256 vs RS256)
- [ ] Token expiry and refresh mechanism
- [ ] Password hashing cost factor (bcrypt rounds)
- [ ] 2FA TOTP implementation security
- [ ] Session fixation prevention
- [ ] Brute force protection (rate limiting)

### 2. Authorization (1-1.5h)
**Files to review:**
- `backend/app/api/admin_*.py` - All admin endpoints
- `backend/app/api/vm_endpoints.py` - VM ownership checks
- `backend/app/services/feature_flag_service.py` - Flag bypass

**Checklist:**
- [ ] Admin route protection (`get_current_admin_user`)
- [ ] VM ownership validation before operations
- [ ] Horizontal privilege escalation (User A → User B)
- [ ] Feature flag hierarchy enforcement
- [ ] Suspended user access blocking

### 3. Input Validation (1-1.5h)
**Files to review:**
- `backend/app/services/cloud_init_generator.py` - Command injection risk
- `backend/app/schemas/*.py` - Pydantic validation
- `backend/app/api/vm_endpoints.py` - VM creation params

**Checklist:**
- [ ] SQL injection (SQLAlchemy parameterized queries)
- [ ] Command injection in cloud-init scripts
- [ ] VM name sanitization
- [ ] Path traversal in file operations
- [ ] XSS in notification templates

### 4. WebSocket Security (30m)
**Files to review:**
- `backend/app/api/vnc-websocket-proxy-endpoint.py`
- `backend/app/api/ssh-console-websocket-endpoint.py`

**Checklist:**
- [ ] WebSocket authentication before connection
- [ ] VM ownership verification
- [ ] Connection timeout handling
- [ ] Data sanitization

### 5. API Security (30m)
**Files to review:**
- `backend/app/main.py` - CORS, middleware
- All API endpoint files

**Checklist:**
- [ ] CORS configuration (`allow_origins=["*"]` issue)
- [ ] Rate limiting implementation
- [ ] Error message disclosure (stack traces)
- [ ] Sensitive data in responses

### 6. Secrets Management (30m)
**Files to review:**
- `backend/app/config.py` - Settings loading
- `.env.example` - Expected secrets
- Audit logs - Password masking

**Checklist:**
- [ ] API keys storage (Telegram, Cloudflare, Email)
- [ ] Password/token masking in logs
- [ ] Secrets in error messages
- [ ] Database credentials handling

## Todo
- [ ] Review authentication flow
- [ ] Verify admin endpoint protection
- [ ] Test VM ownership checks
- [ ] Audit cloud-init for injection
- [ ] Check WebSocket auth
- [ ] Verify CORS configuration
- [ ] Check rate limiting
- [ ] Audit secrets handling

## Output
Report: `reports/phase-02-manual-code-review-findings.md`

## Success Criteria
- All critical paths reviewed
- Findings documented with code references
- Severity levels assigned (Critical/High/Medium/Low)
- Proof-of-concept for vulnerabilities

## Next Steps
→ Phase 3: Infrastructure Review
