# Phase 1: Automated Security Scanning

## Context
- Parent: [plan.md](plan.md)
- Brainstorm: [brainstorm report](../reports/brainstorm-260131-1031-security-audit-vm-portal.md)

## Overview
| Field | Value |
|-------|-------|
| Date | 2026-01-31 |
| Priority | P1 |
| Effort | 2-3 hours |
| Status | pending |

Run automated security tools to identify vulnerabilities in dependencies, code, secrets, and Docker images.

## Tasks

### 1. Dependency Scanning
```bash
# Frontend
cd /home/portal/frontend && npm audit --json > audit-npm.json

# Backend
cd /home/portal/backend && pip-audit --format json > audit-pip.json
```

### 2. Python Static Analysis (Bandit)
```bash
cd /home/portal/backend
bandit -r app/ -f json -o bandit-report.json
```

### 3. Multi-language Static Analysis (Semgrep)
```bash
cd /home/portal
semgrep --config=auto --json -o semgrep-report.json .
```

### 4. Secret Detection
```bash
cd /home/portal
detect-secrets scan --all-files > secrets-report.json

# Git history scan
git log -p | grep -E "(password|secret|key|token)" --context=3 > git-secrets-check.txt
```

### 5. Docker Image Scanning
```bash
trivy image vm-portal-api:latest --format json > trivy-api.json
trivy image vm-portal-frontend:latest --format json > trivy-frontend.json
```

## Todo
- [ ] Install required tools (bandit, semgrep, detect-secrets, trivy, pip-audit)
- [ ] Run npm audit on frontend
- [ ] Run pip-audit on backend
- [ ] Run bandit on Python code
- [ ] Run semgrep with security rules
- [ ] Run detect-secrets scan
- [ ] Scan git history for leaked secrets
- [ ] Run trivy on Docker images
- [ ] Consolidate findings into report

## Output
Report: `reports/phase-01-automated-scanning-findings.md`

## Success Criteria
- All tools executed successfully
- Findings documented with severity levels
- No Critical vulnerabilities in dependencies
- No hardcoded secrets detected

## Risk Assessment
| Risk | Mitigation |
|------|------------|
| Tool not installed | Install via pip/npm/apt |
| False positives | Manual review in Phase 2 |
| Large output | Filter by severity |

## Next Steps
→ Phase 2: Manual Code Review for findings verification
