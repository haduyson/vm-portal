# Phase 3: Infrastructure Security Review - Findings

**Date:** 2026-01-31
**Auditor:** Security Debugger Agent
**Scope:** Docker, Nginx, PostgreSQL, Environment Configuration

---

## Executive Summary

Infrastructure review identified **13 security issues** across Docker containers, Nginx configuration, database setup, and environment handling:
- **Critical:** 4 findings
- **High:** 5 findings
- **Medium:** 3 findings
- **Low:** 1 finding

Major concerns: containers running as root, exposed database ports, missing security headers, weak default credentials, disabled AppArmor, and no resource limits.

---

## Critical Findings

### [INFRA-01] Backend Container Running as Root
- **Severity:** Critical
- **Component:** Docker (Backend)
- **Location:** `backend/Dockerfile`
- **Description:** Backend container runs as root user with full privileges
- **Evidence:**
```dockerfile
FROM python:3.12
WORKDIR /app
# No USER directive - runs as root (UID 0)
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
```
- **Risk:** Container escape or compromise grants root access to host system, lateral movement to other containers
- **Recommendation:**
  - Add non-root user before CMD:
    ```dockerfile
    RUN groupadd -r appuser && useradd -r -g appuser appuser
    RUN chown -R appuser:appuser /app
    USER appuser
    ```

---

### [INFRA-02] Database Exposed to Host Network
- **Severity:** Critical
- **Component:** PostgreSQL
- **Location:** `docker-compose.yml` line 15-16
- **Description:** PostgreSQL port 5432 exposed to host, accessible outside Docker network
- **Evidence:**
```yaml
db:
  ports:
    - "5432:5432"  # Exposed to host and potentially external network
```
- **Risk:** Direct database access from host/network bypassing application layer; brute force attacks on DB credentials; unauthorized data access
- **Recommendation:**
  - Remove port mapping entirely - only internal services need DB access:
    ```yaml
    # Remove:
    # ports:
    #   - "5432:5432"
    ```
  - Access via `docker exec` if needed for admin tasks

---

### [INFRA-03] Weak Default Database Credentials
- **Severity:** Critical
- **Component:** PostgreSQL
- **Location:** `docker-compose.yml` line 8-10, `.env.example` line 3-5
- **Description:** Fallback to weak default password "password" if env vars not set
- **Evidence:**
```yaml
environment:
  POSTGRES_USER: ${DB_USER:-vmadmin}
  POSTGRES_PASSWORD: ${DB_PASSWORD:-password}  # Weak default
  POSTGRES_DB: ${DB_NAME:-vmportal}
```
```env
DB_PASSWORD=your_secure_password  # Example not enforcing strength
```
- **Risk:** Production deployments with default credentials; unauthorized database access; data breach
- **Recommendation:**
  - Remove defaults, fail startup if missing:
    ```yaml
    POSTGRES_PASSWORD: ${DB_PASSWORD:?DB_PASSWORD must be set}
    ```
  - Add password complexity requirements to documentation
  - Generate random passwords in setup scripts

---

### [INFRA-04] AppArmor Security Disabled on All Containers
- **Severity:** Critical
- **Component:** Docker
- **Location:** `docker-compose.yml` lines 5-6, 28-29, 47-48
- **Description:** AppArmor confinement disabled using `apparmor:unconfined` on db, api, nginx
- **Evidence:**
```yaml
db:
  security_opt:
    - apparmor:unconfined  # Disables mandatory access control

api:
  security_opt:
    - apparmor:unconfined

nginx:
  security_opt:
    - apparmor:unconfined
```
- **Risk:** Containers can bypass AppArmor restrictions; increased attack surface if container compromised; no MAC layer protection
- **Recommendation:**
  - Remove `security_opt` entirely to use default AppArmor profile
  - If specific capabilities needed, create custom AppArmor profiles instead of disabling entirely

---

## High Severity Findings

### [INFRA-05] Missing Critical Security Headers
- **Severity:** High
- **Component:** Nginx
- **Location:** `nginx/nginx.conf`
- **Description:** Missing essential HTTP security headers
- **Evidence:** No headers found for:
  - `X-Frame-Options` - clickjacking protection
  - `X-Content-Type-Options` - MIME sniffing protection
  - `X-XSS-Protection` - XSS filter
  - `Content-Security-Policy` - XSS/injection protection
  - `Strict-Transport-Security` - HSTS enforcement
  - `Referrer-Policy` - referrer leakage control
  - `Permissions-Policy` - browser feature control
- **Risk:** Clickjacking attacks, MIME confusion attacks, XSS vulnerabilities, protocol downgrade attacks
- **Recommendation:**
  - Add security headers to HTTPS server block:
    ```nginx
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;
    ```

---

### [INFRA-06] Backend API Port Exposed to Host
- **Severity:** High
- **Component:** Docker (Backend)
- **Location:** `docker-compose.yml` line 32-33
- **Description:** Backend API port 8000 exposed to host, allowing direct API access bypassing Nginx
- **Evidence:**
```yaml
api:
  ports:
    - "8000:8000"  # Direct host access to API
```
- **Risk:** Bypass Nginx security controls, rate limiting, SSL termination; direct HTTP access to API without HTTPS
- **Recommendation:**
  - Remove port mapping - API should only be accessible via Nginx reverse proxy:
    ```yaml
    # Remove:
    # ports:
    #   - "8000:8000"
    ```

---

### [INFRA-07] No Rate Limiting on API Endpoints
- **Severity:** High
- **Component:** Nginx
- **Location:** `nginx/nginx.conf`
- **Description:** No rate limiting configured for API endpoints
- **Evidence:** No `limit_req_zone` or `limit_req` directives found
- **Risk:** Brute force attacks on authentication; DoS attacks; credential stuffing; resource exhaustion
- **Recommendation:**
  - Add rate limiting:
    ```nginx
    http {
      limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;
      limit_req_zone $binary_remote_addr zone=auth_limit:10m rate=5r/m;

      server {
        location /api/auth/ {
          limit_req zone=auth_limit burst=3 nodelay;
        }
        location /api/ {
          limit_req zone=api_limit burst=20 nodelay;
        }
      }
    }
    ```

---

### [INFRA-08] No Request Size Limits
- **Severity:** High
- **Component:** Nginx
- **Location:** `nginx/nginx.conf`
- **Description:** No `client_max_body_size` or `client_body_buffer_size` configured
- **Evidence:** Default Nginx limit (1MB) may be insufficient for file uploads but no explicit control
- **Risk:** DoS via large payloads; memory exhaustion; uncontrolled file upload sizes
- **Recommendation:**
  - Set explicit limits based on application needs:
    ```nginx
    http {
      client_max_body_size 10M;  # Adjust based on needs
      client_body_buffer_size 128k;
      client_header_buffer_size 1k;
      large_client_header_buffers 4 8k;
    }
    ```

---

### [INFRA-09] Development Mode in Production Dockerfile
- **Severity:** High
- **Component:** Docker (Backend)
- **Location:** `backend/Dockerfile` line 12
- **Description:** Uvicorn runs with `--reload` flag (development mode)
- **Evidence:**
```dockerfile
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
```
- **Risk:** Auto-reload watches filesystem (performance overhead); may expose additional debug endpoints; not optimized for production
- **Recommendation:**
  - Remove `--reload` flag for production:
    ```dockerfile
    CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "4"]
    ```
  - Consider multi-stage build with separate dev/prod images

---

## Medium Severity Findings

### [INFRA-10] No Resource Limits on Containers
- **Severity:** Medium
- **Component:** Docker
- **Location:** `docker-compose.yml` (all services)
- **Description:** No CPU or memory limits configured for any container
- **Evidence:** No `deploy.resources.limits` sections found
- **Risk:** Resource exhaustion; single container consuming all host resources; DoS scenarios
- **Recommendation:**
  - Add resource constraints:
    ```yaml
    api:
      deploy:
        resources:
          limits:
            cpus: '2.0'
            memory: 2G
          reservations:
            cpus: '0.5'
            memory: 512M

    db:
      deploy:
        resources:
          limits:
            cpus: '2.0'
            memory: 4G
          reservations:
            cpus: '1.0'
            memory: 1G
    ```

---

### [INFRA-11] Host Filesystem Mounts in API Container
- **Severity:** Medium
- **Component:** Docker (Backend)
- **Location:** `docker-compose.yml` lines 38-42
- **Description:** Multiple host filesystem paths mounted into container
- **Evidence:**
```yaml
volumes:
  - ./backend:/app  # Entire backend mounted
  - /var/lock/qemu-server:/var/lock/qemu-server:ro
  - /etc/cloudflared:/etc/cloudflared  # RW mount
  - /var/lib/vz/snippets:/var/lib/vz/snippets  # RW mount
```
- **Risk:** Container escape could access/modify host files; secrets exposure from host; privilege escalation potential
- **Recommendation:**
  - Make all mounts read-only where possible:
    ```yaml
    - /etc/cloudflared:/etc/cloudflared:ro
    - /var/lib/vz/snippets:/var/lib/vz/snippets:ro
    ```
  - Remove `./backend:/app` mount in production (dev only)
  - Use named volumes instead of host paths where possible

---

### [INFRA-12] No CORS Headers Configuration
- **Severity:** Medium
- **Component:** Nginx
- **Location:** `nginx/nginx.conf`
- **Description:** No explicit CORS headers configured in Nginx
- **Evidence:** No `Access-Control-Allow-*` headers found
- **Risk:** Depends on application handling; inconsistent CORS enforcement; potential XSS if misconfigured in app
- **Recommendation:**
  - Add explicit CORS control at Nginx level for defense-in-depth:
    ```nginx
    location /api/ {
      if ($request_method = 'OPTIONS') {
        add_header 'Access-Control-Allow-Origin' 'https://portal.hasontech.vn' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'Authorization, Content-Type' always;
        add_header 'Access-Control-Max-Age' 1728000;
        add_header 'Content-Length' 0;
        return 204;
      }
    }
    ```

---

## Low Severity Findings

### [INFRA-13] Weak SSL Cipher Suite
- **Severity:** Low
- **Component:** Nginx
- **Location:** `nginx/nginx.conf` line 30
- **Description:** SSL cipher configuration could be stronger
- **Evidence:**
```nginx
ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
ssl_prefer_server_ciphers off;
```
- **Risk:** Limited but acceptable cipher suite; missing modern ciphers like ChaCha20
- **Recommendation:**
  - Use Mozilla Modern cipher suite:
    ```nginx
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384';
    ssl_prefer_server_ciphers on;
    ```

---

## Positive Security Findings

### Strengths Identified:

1. **TLS Configuration:** Strong TLS 1.2+ only (line 29)
2. **HTTPS Enforcement:** HTTP to HTTPS redirect (line 16)
3. **Environment File Protection:** `.env` properly in `.gitignore`
4. **Database Health Checks:** PostgreSQL healthcheck configured (lines 17-21)
5. **Session Security:** SSL session caching configured (lines 32-33)
6. **Dependency Checks:** Services depend on DB health (lines 34-36)
7. **Read-only Mounts:** Some paths mounted read-only (line 39, 42)
8. **Alpine Base:** Nginx uses minimal Alpine image

---

## Summary Statistics

| Severity | Count | Components Affected |
|----------|-------|---------------------|
| Critical | 4 | Docker, PostgreSQL, All Containers |
| High | 5 | Docker, Nginx |
| Medium | 3 | Docker, Nginx |
| Low | 1 | Nginx |
| **Total** | **13** | **All Infrastructure** |

---

## Priority Recommendations

### Immediate Actions (Critical):
1. Remove database port exposure (`INFRA-02`)
2. Disable AppArmor unconfined mode (`INFRA-04`)
3. Remove API port exposure (`INFRA-06`)
4. Add non-root users to containers (`INFRA-01`)

### Short-term (High):
1. Add security headers (`INFRA-05`)
2. Implement rate limiting (`INFRA-07`)
3. Remove `--reload` from production (`INFRA-09`)
4. Set request size limits (`INFRA-08`)

### Medium-term (Medium/Low):
1. Add resource limits (`INFRA-10`)
2. Make host mounts read-only (`INFRA-11`)
3. Configure CORS headers (`INFRA-12`)
4. Strengthen cipher suite (`INFRA-13`)

---

## Unresolved Questions

1. Is the exposed DB port (5432) required for external admin tools or can it be removed?
2. What is the maximum expected file upload size for the application (for `client_max_body_size`)?
3. Are the host filesystem mounts (`/etc/cloudflared`, `/var/lib/vz/snippets`) required to be read-write?
4. What is the expected rate limit for authenticated vs unauthenticated API requests?
5. Does the backend need the entire `./backend:/app` mount in production or is this dev-only?
