# Phase 2: Manual Code Review Security Findings

**Date:** 2026-01-31
**Auditor:** Security Audit Agent
**Scope:** VM Portal Backend Application

---

## Executive Summary

Manual security review of critical code paths identified **15 security issues** ranging from Critical to Low severity. Key concerns:

- **CRITICAL**: No suspended user enforcement, CORS allows all origins, weak default secrets
- **HIGH**: No rate limiting, bcrypt rounds not configured, VNC WebSocket lacks auth
- **MEDIUM**: Missing HTTPS enforcement, weak JWT algorithm, no session management
- **LOW**: AutoAddPolicy in SSH, potential XSS in templates

---

## CRITICAL FINDINGS

### [FINDING-01] Suspended Users Not Blocked from Access

- **Severity:** Critical
- **CVSS:** 9.1 (High)
- **Location:** `backend/app/core/security.py:110-138`
- **CWE:** CWE-285 (Improper Authorization)
- **Description:** `get_current_user` does not check `user.is_suspended` flag. Suspended users can still authenticate and access all resources.
- **Impact:** Admin suspends malicious user but they retain full access to VMs, can create/delete resources, access sensitive data.
- **Code Evidence:**
  ```python
  async def get_current_user(
      credentials: HTTPAuthorizationCredentials = Depends(security),
      session: AsyncSession = Depends(get_session),
  ) -> User:
      # ... JWT validation ...
      user = result.scalar_one_or_none()
      if user is None:
          raise credentials_exception
      # MISSING: if user.is_suspended: raise HTTPException(403)
      return user
  ```
- **Recommendation:** Add suspended check:
  ```python
  if user.is_suspended:
      raise HTTPException(
          status_code=status.HTTP_403_FORBIDDEN,
          detail="Tài khoản đã bị khóa"
      )
  ```

---

### [FINDING-02] CORS Allows All Origins

- **Severity:** Critical
- **CVSS:** 8.6 (High)
- **Location:** `backend/app/main.py:84-90`
- **CWE:** CWE-942 (Permissive Cross-domain Policy)
- **Description:** CORS configured with `allow_origins=["*"]`, allows any website to make authenticated requests.
- **Impact:** CSRF attacks, malicious sites can steal user tokens, perform actions on behalf of users.
- **Code Evidence:**
  ```python
  app.add_middleware(
      CORSMiddleware,
      allow_origins=["*"],  # CRITICAL: Allows any origin!
      allow_credentials=True,
      allow_methods=["*"],
      allow_headers=["*"],
  )
  ```
- **Recommendation:** Restrict to specific frontend origins:
  ```python
  allow_origins=[
      "http://localhost:3000",
      "https://portal.yourdomain.com"
  ]
  ```

---

### [FINDING-03] Weak Default SECRET_KEY

- **Severity:** Critical
- **CVSS:** 9.3 (Critical)
- **Location:** `backend/app/config.py:9`
- **CWE:** CWE-798 (Use of Hard-coded Credentials)
- **Description:** Default JWT `SECRET_KEY` is `"change-me-in-production"`. If not changed, attackers can forge tokens.
- **Impact:** Full authentication bypass, attackers can generate admin tokens, access any user account.
- **Code Evidence:**
  ```python
  SECRET_KEY: str = "change-me-in-production"
  ```
- **Recommendation:**
  1. Remove default value, make required from env
  2. Add startup check to validate SECRET_KEY strength
  3. Use cryptographically random 64+ char key

---

### [FINDING-04] VNC WebSocket Lacks Authentication

- **Severity:** Critical
- **CVSS:** 9.8 (Critical)
- **Location:** `backend/app/api/vnc-websocket-proxy-endpoint.py:65-88`
- **CWE:** CWE-306 (Missing Authentication)
- **Description:** VNC WebSocket endpoint accepts connections without JWT auth, only validates `vmid` exists. No ownership check.
- **Impact:** Any unauthenticated user can access any VM's VNC console by guessing vmid.
- **Code Evidence:**
  ```python
  @router.websocket("/vnc-ws")
  async def vnc_websocket_proxy(
      websocket: WebSocket,
      vmid: int = Query(...),
      session: AsyncSession = Depends(get_session),
  ):
      # NO JWT VALIDATION HERE!
      await websocket.accept()
      # ... gets VM without ownership check
  ```
- **Recommendation:** Add JWT auth similar to SSH console:
  ```python
  @router.websocket("/vnc-ws")
  async def vnc_websocket_proxy(
      websocket: WebSocket,
      vmid: int = Query(...),
      token: str = Query(...),
      session: AsyncSession = Depends(get_session),
  ):
      current_user = await verify_websocket_token(token, session)
      if not current_user:
          await websocket.close(code=1008)
          return
      # Verify VM ownership
      if vm.user_id != current_user.id and not current_user.is_admin:
          await websocket.close(code=1008)
          return
  ```

---

## HIGH FINDINGS

### [FINDING-05] No Rate Limiting on Authentication

- **Severity:** High
- **CVSS:** 7.5 (High)
- **Location:** `backend/app/api/auth_endpoints.py:37-80`
- **CWE:** CWE-307 (Improper Restriction of Excessive Authentication Attempts)
- **Description:** Login endpoint has no rate limiting or account lockout. Allows unlimited brute force attempts.
- **Impact:** Attackers can brute force weak passwords, credential stuffing attacks.
- **Code Evidence:**
  ```python
  @router.post("/login")
  async def login(credentials: UserLogin, session: AsyncSession = Depends(get_session)):
      # No rate limiting decorator or check
  ```
- **Recommendation:**
  1. Add rate limiting (e.g., slowapi, fastapi-limiter)
  2. Implement account lockout after N failed attempts
  3. Add CAPTCHA after 3 failed attempts

---

### [FINDING-06] Bcrypt Rounds Not Configured (Using Default)

- **Severity:** High
- **CVSS:** 6.8 (Medium)
- **Location:** `backend/app/core/security.py:16`
- **CWE:** CWE-916 (Use of Password Hash With Insufficient Computational Effort)
- **Description:** Bcrypt rounds not explicitly set, uses passlib default (~10-12 rounds). Modern standard is 12-14.
- **Impact:** Passwords more vulnerable to offline brute force if DB compromised.
- **Code Evidence:**
  ```python
  pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
  # No rounds configuration
  ```
- **Recommendation:**
  ```python
  pwd_context = CryptContext(
      schemes=["bcrypt"],
      deprecated="auto",
      bcrypt__rounds=12,  # Explicit rounds
  )
  ```

---

### [FINDING-07] JWT Algorithm HS256 (Symmetric)

- **Severity:** High
- **CVSS:** 6.5 (Medium)
- **Location:** `backend/app/config.py:11`, `backend/app/core/security.py:41,55,123`
- **CWE:** CWE-327 (Use of a Broken or Risky Cryptographic Algorithm)
- **Description:** HS256 symmetric algorithm used for JWT. If SECRET_KEY leaks, attackers forge tokens. RS256 asymmetric preferred.
- **Impact:** Single key compromise = full auth bypass.
- **Code Evidence:**
  ```python
  ALGORITHM: str = "HS256"
  jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
  ```
- **Recommendation:** Migrate to RS256 with private/public key pair for better security isolation.

---

### [FINDING-08] No Refresh Token Rotation on Failure

- **Severity:** High
- **CVSS:** 6.2 (Medium)
- **Location:** `backend/app/api/auth_endpoints.py:132-169`
- **CWE:** CWE-384 (Session Fixation)
- **Description:** Refresh endpoint rotates tokens on success but not on partial failures. Replay attack window exists.
- **Impact:** Stolen refresh tokens can be reused before detection.
- **Code Evidence:**
  ```python
  token_record = await verify_refresh_token(session, request.refresh_token)
  if not token_record:
      raise HTTPException(...)  # Token not revoked on invalid attempt
  ```
- **Recommendation:** Revoke token on any verification failure to prevent replay.

---

## MEDIUM FINDINGS

### [FINDING-09] No HTTPS Enforcement

- **Severity:** Medium
- **CVSS:** 5.9 (Medium)
- **Location:** `backend/app/main.py`
- **CWE:** CWE-319 (Cleartext Transmission of Sensitive Information)
- **Description:** No HTTPS redirect or HSTS headers enforced. JWTs/passwords can be intercepted over HTTP.
- **Impact:** Man-in-the-middle attacks, credential theft.
- **Recommendation:** Add HTTPS redirect middleware and HSTS headers:
  ```python
  from fastapi.middleware.httpsredirect import HTTPSRedirectMiddleware
  app.add_middleware(HTTPSRedirectMiddleware)

  @app.middleware("http")
  async def add_security_headers(request, call_next):
      response = await call_next(request)
      response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
      return response
  ```

---

### [FINDING-10] JWT Tokens Not Validated for Type in All Paths

- **Severity:** Medium
- **CVSS:** 5.4 (Medium)
- **Location:** `backend/app/core/security.py:126`
- **CWE:** CWE-863 (Incorrect Authorization)
- **Description:** Partial 2FA tokens blocked in `get_current_user` but edge case exists if `type` field missing.
- **Impact:** Potential auth bypass using malformed tokens.
- **Code Evidence:**
  ```python
  token_type: str = payload.get("type", "access")
  if username is None or token_type == "partial_2fa":
      raise credentials_exception
  # What if token_type is something else unexpected?
  ```
- **Recommendation:** Whitelist only `"access"` type:
  ```python
  if token_type != "access":
      raise credentials_exception
  ```

---

### [FINDING-11] VM Name Validation Allows Injection Patterns

- **Severity:** Medium
- **CVSS:** 5.3 (Medium)
- **Location:** `backend/app/schemas/vm_schemas.py:10-18`
- **CWE:** CWE-20 (Improper Input Validation)
- **Description:** VM name regex allows hyphens but doesn't prevent starting/ending with hyphen or double hyphens (DNS issues).
- **Impact:** DNS/hostname resolution failures, potential command injection if names used in shell.
- **Code Evidence:**
  ```python
  if not re.match(r'^[a-zA-Z][a-zA-Z0-9\-]*$', v):
  # Allows: "test--name", "test-"
  ```
- **Recommendation:**
  ```python
  if not re.match(r'^[a-zA-Z][a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*$', v):
  ```

---

### [FINDING-12] Cloud-Init Contains Shell Commands Without Escaping

- **Severity:** Medium
- **CVSS:** 5.1 (Medium)
- **Location:** `backend/app/services/cloud_init_generator.py:239-256`
- **CWE:** CWE-78 (OS Command Injection)
- **Description:** Cloud-init YAML contains direct shell commands. If vm_name or other inputs not sanitized upstream, injection risk.
- **Impact:** Shell command injection during VM provisioning.
- **Code Evidence:**
  ```python
  "runcmd": [
      "sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config",
      # Commands hardcoded, but if vm_name used: potential injection
  ```
- **Recommendation:** Ensure all user inputs sanitized before cloud-init, use YAML escaping for any dynamic values.

---

### [FINDING-13] Email Templates Use Unescaped HTML

- **Severity:** Medium
- **CVSS:** 4.7 (Medium)
- **Location:** `backend/app/services/email-notification-templates.py:56,72-77`
- **CWE:** CWE-79 (Cross-site Scripting)
- **Description:** User-controlled values (vm_name, username) inserted into HTML without escaping.
- **Impact:** XSS in email clients if attacker controls vm_name/username.
- **Code Evidence:**
  ```python
  <div class="info-value">{vm_name}</div>
  <div class="info-value">{username}</div>
  # No HTML escaping
  ```
- **Recommendation:** Use `html.escape()` for all user-controlled values:
  ```python
  import html
  <div class="info-value">{html.escape(vm_name)}</div>
  ```

---

## LOW FINDINGS

### [FINDING-14] SSH AutoAddPolicy Accepts Any Host Key

- **Severity:** Low
- **CVSS:** 3.9 (Low)
- **Location:** `backend/app/api/ssh-console-websocket-endpoint.py:145-146`
- **CWE:** CWE-295 (Improper Certificate Validation)
- **Description:** SSH client uses AutoAddPolicy which accepts any host key (no MITM protection).
- **Impact:** MITM attacks on internal network possible if attacker controls routing.
- **Code Evidence:**
  ```python
  ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  # Note in code: "acceptable for internal trusted networks"
  ```
- **Recommendation:** For production with untrusted networks, implement known_hosts verification or host key pinning.

---

### [FINDING-15] No Password Masking in Logs

- **Severity:** Low
- **CVSS:** 3.3 (Low)
- **Location:** Various endpoints
- **CWE:** CWE-532 (Insertion of Sensitive Information into Log File)
- **Description:** No evidence of password masking in logs. Generic exceptions may log sensitive data.
- **Impact:** Passwords leaked in logs if exceptions occur.
- **Recommendation:**
  1. Implement logging filter to mask passwords
  2. Never log request bodies containing credentials
  3. Use structured logging with sensitive field redaction

---

## Summary Statistics

| Severity | Count | CVSS Range |
|----------|-------|------------|
| Critical | 4     | 8.6-9.8    |
| High     | 4     | 6.2-7.5    |
| Medium   | 5     | 4.7-5.9    |
| Low      | 2     | 3.3-3.9    |
| **Total**| **15**|            |

---

## Priority Remediation Roadmap

### Immediate (Week 1)
1. **FINDING-01**: Add suspended user check
2. **FINDING-04**: Add VNC WebSocket authentication
3. **FINDING-03**: Validate SECRET_KEY on startup

### Short-term (Week 2-3)
4. **FINDING-02**: Restrict CORS origins
5. **FINDING-05**: Implement rate limiting
6. **FINDING-09**: Add HTTPS enforcement

### Medium-term (Month 1)
7. **FINDING-06**: Configure bcrypt rounds
8. **FINDING-08**: Add refresh token revocation on failure
9. **FINDING-13**: Escape HTML in email templates

### Long-term (Month 2+)
10. **FINDING-07**: Migrate to RS256 JWT
11. **FINDING-14**: Implement SSH host key verification
12. **FINDING-15**: Add password masking to logs

---

## Unresolved Questions

1. Is there a Web Application Firewall (WAF) in front of the API?
2. Are there any IP whitelisting rules for admin endpoints?
3. What is the actual bcrypt rounds value being used (needs runtime check)?
4. Is the SECRET_KEY rotated periodically?
5. Are there any intrusion detection systems (IDS) monitoring auth failures?

---

**End of Phase 2 Report**
