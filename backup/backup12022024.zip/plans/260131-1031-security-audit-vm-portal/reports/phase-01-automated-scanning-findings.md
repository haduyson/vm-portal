# Security Audit Phase 1: Automated Scanning Findings

**Date:** 2026-01-31
**Auditor:** Security Debugger Agent
**Scope:** VM Portal (Backend + Frontend + Infrastructure)

---

## Executive Summary

Comprehensive automated security scanning identified **19 security findings** across multiple severity levels:
- **Critical:** 3 findings
- **High:** 5 findings
- **Medium:** 7 findings
- **Low/Info:** 4 findings

Primary concerns: hardcoded secrets in config, disabled SSL verification, lack of security headers, CORS misconfiguration, weak password generation, missing rate limiting.

---

## CRITICAL SEVERITY FINDINGS

### Finding #1: Hardcoded Default Credentials
- **Severity:** Critical
- **Location:** `backend/app/config.py:9,15`
- **Category:** Authentication Security
- **Description:** Hardcoded default admin credentials in source code
- **Evidence:**
  ```python
  SECRET_KEY: str = "change-me-in-production"
  DEFAULT_ADMIN_PASSWORD: str = "Admin@123"
  ```
- **Impact:** Attackers can access system with known credentials if not changed. SECRET_KEY compromise allows JWT token forgery
- **Remediation:**
  - Remove defaults from code
  - Require SECRET_KEY from environment (fail if not set)
  - Force admin password change on first login
  - Generate random SECRET_KEY in deployment docs

### Finding #2: Database Credentials in Source Code
- **Severity:** Critical
- **Location:** `backend/app/config.py:6`
- **Category:** Data Security
- **Description:** Default database connection string contains plaintext credentials
- **Evidence:**
  ```python
  DATABASE_URL: str = "postgresql+asyncpg://vmadmin:password@db:5432/vmportal"
  ```
- **Impact:** Database compromise if default credentials used in production
- **Remediation:**
  - Remove default with credentials
  - Require DATABASE_URL from environment
  - Use strong generated passwords in deployment

### Finding #3: SSL Certificate Verification Disabled
- **Severity:** Critical
- **Location:**
  - `backend/app/config.py:25`
  - `backend/app/api/vnc-websocket-proxy-endpoint.py:25,46,146`
- **Category:** Transport Security
- **Description:** SSL/TLS certificate verification disabled for Proxmox connections
- **Evidence:**
  ```python
  PROXMOX_VERIFY_SSL: bool = False
  ssl_ctx.check_hostname = False
  ssl_ctx.verify_mode = ssl.CERT_NONE
  ```
- **Impact:** Man-in-the-middle attacks possible, credentials interceptable
- **Remediation:**
  - Enable SSL verification by default
  - Provide option to add custom CA cert
  - Warn admins about security implications if disabled

---

## HIGH SEVERITY FINDINGS

### Finding #4: Unrestricted CORS Configuration
- **Severity:** High
- **Location:** `backend/app/main.py:86`
- **Category:** Web Security
- **Description:** CORS allows all origins with credentials enabled
- **Evidence:**
  ```python
  app.add_middleware(
      CORSMiddleware,
      allow_origins=["*"],
      allow_credentials=True,
      allow_methods=["*"],
      allow_headers=["*"],
  )
  ```
- **Impact:** Cross-site request forgery (CSRF) attacks possible from any domain
- **Remediation:**
  - Restrict to specific frontend origin(s)
  - Use environment variable for allowed origins
  - Consider CSRF token implementation

### Finding #5: Weak Password Generation (Cloud-init)
- **Severity:** High
- **Location:** `backend/app/services/cloud_init_generator.py:189`
- **Category:** Cryptography
- **Description:** Using non-cryptographic `random.choices()` for password generation
- **Evidence:**
  ```python
  import random
  password = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
  ```
- **Impact:** Predictable passwords if random seed known, VM SSH compromise
- **Remediation:**
  - Use `secrets` module instead of `random`
  - Already using `secrets` in `generate_random_password.py` - apply same pattern

### Finding #6: Deprecated datetime.utcnow() Usage
- **Severity:** High
- **Location:** Multiple files (9+ instances)
  - `backend/app/core/security.py:36,38,47,66,84`
  - `backend/app/api/auth_endpoints.py:56,302`
  - `backend/app/api/admin_user_endpoints.py:237`
- **Category:** Time Handling
- **Description:** Using deprecated `datetime.utcnow()` (removed in Python 3.12+)
- **Evidence:**
  ```python
  expire = datetime.utcnow() + timedelta(minutes=5)
  ```
- **Impact:** Future compatibility issues, potential timezone bugs
- **Remediation:** Replace with `datetime.now(timezone.utc)`

### Finding #7: No Rate Limiting on Authentication Endpoints
- **Severity:** High
- **Location:** `backend/app/api/auth_endpoints.py`
- **Category:** Authentication Security
- **Description:** Login endpoint has no rate limiting or brute force protection
- **Evidence:** No rate limiting middleware or login attempt tracking found
- **Impact:** Brute force attacks possible against user accounts
- **Remediation:**
  - Implement rate limiting (e.g., slowapi, fastapi-limiter)
  - Add login attempt tracking
  - Temporary account lockout after failed attempts
  - CAPTCHA after multiple failures

### Finding #8: Missing Security Headers
- **Severity:** High
- **Location:** `nginx/nginx.conf`, `backend/app/main.py`
- **Category:** Web Security
- **Description:** No security headers configured (X-Frame-Options, CSP, HSTS, etc.)
- **Evidence:** No security header directives in nginx config or FastAPI middleware
- **Impact:** Clickjacking, XSS, content sniffing attacks
- **Remediation:** Add nginx headers:
  ```nginx
  add_header X-Frame-Options "SAMEORIGIN" always;
  add_header X-Content-Type-Options "nosniff" always;
  add_header X-XSS-Protection "1; mode=block" always;
  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
  add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'" always;
  add_header Referrer-Policy "strict-origin-when-cross-origin" always;
  ```

---

## MEDIUM SEVERITY FINDINGS

### Finding #9: Subprocess Execution Without Input Validation
- **Severity:** Medium
- **Location:** `backend/app/api/admin-cloudflare-setup-wizard-endpoints.py:225,449,457,465,473`
- **Category:** Command Injection
- **Description:** Using `asyncio.create_subprocess_exec` with systemd commands
- **Evidence:**
  ```python
  proc = await asyncio.create_subprocess_exec(
      "cloudflared", "version",
      stdout=asyncio.subprocess.PIPE,
      stderr=asyncio.subprocess.PIPE
  )
  ```
- **Impact:** Low risk (hardcoded commands, admin-only), but subprocess execution always requires scrutiny
- **Remediation:**
  - Already using exec (not shell) - good practice
  - Admin-only access mitigates risk
  - Consider additional validation if accepting user input

### Finding #10: File Write Operations Without Path Validation
- **Severity:** Medium
- **Location:**
  - `backend/app/api/admin-cloudflare-setup-wizard-endpoints.py:305,427`
  - `backend/app/services/cloudflare-tunnel-service.py:195`
  - `backend/app/services/cloud_init_generator.py:280`
- **Category:** Path Traversal
- **Description:** File writes to paths without traversal validation
- **Evidence:**
  ```python
  with open(credentials_path, "w") as f:
      f.write(credentials_content)
  ```
- **Impact:** Path traversal if attacker controls path variables (admin-only reduces risk)
- **Remediation:**
  - Validate paths with `os.path.realpath()` and whitelist directories
  - Use `pathlib.Path().resolve()` to prevent traversal
  - Add path existence/permission checks

### Finding #11: Broad Exception Handling
- **Severity:** Medium
- **Location:** Multiple locations (310+ instances across codebase)
- **Category:** Error Handling
- **Description:** Generic `except Exception:` and bare `except:` blocks suppress specific errors
- **Evidence:**
  ```python
  except Exception:
      # File write failed - return content for manual save
      pass
  ```
- **Impact:** Security errors may be silently ignored, making debugging difficult
- **Remediation:**
  - Catch specific exception types
  - Log all caught exceptions
  - Re-raise security-critical exceptions

### Finding #12: Sensitive Data in Logs Risk
- **Severity:** Medium
- **Location:** Multiple print statements throughout codebase
- **Category:** Information Disclosure
- **Description:** Using `print()` instead of proper logging may expose sensitive data
- **Evidence:** Multiple print statements in main.py, services, etc.
- **Impact:** Credentials/tokens in logs if exception context printed
- **Remediation:**
  - Replace print with structured logging
  - Configure log filtering for sensitive fields
  - Use log levels appropriately (debug vs info vs error)

### Finding #13: No CSRF Protection
- **Severity:** Medium
- **Location:** FastAPI application
- **Category:** Web Security
- **Description:** No CSRF token validation on state-changing operations
- **Evidence:** Only JWT bearer tokens used, no CSRF tokens
- **Impact:** CSRF attacks possible if JWT stored in cookies or local storage accessible via XSS
- **Remediation:**
  - Current JWT-in-header approach partially mitigates (not auto-sent)
  - Consider double-submit cookie pattern for additional protection
  - Ensure JWT never stored in cookies without SameSite=Strict

### Finding #14: No Request Timeout Configuration
- **Severity:** Medium
- **Location:** HTTP client usage in Cloudflare/Telegram services
- **Category:** Availability
- **Description:** aiohttp sessions created without timeout configuration
- **Evidence:**
  ```python
  async with aiohttp.ClientSession() as session:
      async with session.get(url, headers=self._headers) as resp:
  ```
- **Impact:** Slowloris attacks, resource exhaustion from hanging connections
- **Remediation:**
  - Configure ClientTimeout for all aiohttp sessions
  - Set reasonable defaults (e.g., 30s total, 10s connect)

### Finding #15: Missing Input Sanitization on User-Controlled Fields
- **Severity:** Medium
- **Location:** VM creation, user schemas
- **Category:** Input Validation
- **Description:** Limited sanitization beyond Pydantic validation
- **Evidence:** Basic regex validation in schemas, no HTML escaping
- **Impact:** Potential for stored XSS if data reflected in admin UI
- **Remediation:**
  - Add HTML entity escaping for display
  - Validate/sanitize all user inputs at API boundary
  - Consider using bleach library for text sanitization

---

## LOW/INFORMATIONAL FINDINGS

### Finding #16: Outdated Python Package Versions
- **Severity:** Low
- **Location:** `backend/requirements.txt`
- **Category:** Dependency Security
- **Description:** Some packages may have known vulnerabilities
- **Evidence:**
  ```
  python-jose[cryptography]==3.3.0  # Released 2021
  passlib[bcrypt]==1.7.4  # Released 2020
  ```
- **Impact:** Depends on specific CVEs, generally low for this stack
- **Remediation:**
  - Run `pip-audit` or `safety check` regularly
  - Update packages quarterly
  - Pin major versions but allow patch updates
  - Monitor GitHub security advisories

### Finding #17: No Audit Logging for Sensitive Operations
- **Severity:** Low
- **Location:** Admin endpoints, user management
- **Category:** Auditing
- **Description:** Limited audit trail for admin actions beyond basic audit_log table
- **Evidence:** Audit logging exists but may not cover all sensitive ops
- **Impact:** Difficult to investigate security incidents
- **Remediation:**
  - Audit all admin actions (user creation, VM deletion, setting changes)
  - Log authentication failures
  - Include IP addresses, timestamps, user agents
  - Consider SIEM integration

### Finding #18: Frontend Dependency Vulnerabilities (Potential)
- **Severity:** Low
- **Location:** `frontend/package.json`
- **Category:** Dependency Security
- **Description:** Unable to run npm audit (permission denied), but should be checked
- **Evidence:**
  ```json
  "axios": "^1.6.8",
  "react": "^18.2.0",
  "@mui/material": "^5.15.15"
  ```
- **Impact:** Depends on specific vulnerabilities in dependencies
- **Remediation:**
  - Run `npm audit` and `npm audit fix`
  - Update to latest stable versions
  - Enable Dependabot/Renovate for automated updates

### Finding #19: .env File in Root Directory
- **Severity:** Low (informational)
- **Location:** `/home/portal/.env`
- **Category:** Configuration Security
- **Description:** Environment file exists in repo root
- **Evidence:** `.env` file present, `.gitignore` includes it
- **Impact:** Low if properly gitignored, but risk of accidental commit
- **Remediation:**
  - Verify `.env` is in `.gitignore` ✓ (confirmed)
  - Use `.env.example` for documentation ✓ (exists)
  - Consider git-secrets or pre-commit hooks to prevent commits
  - Rotate all secrets if ever committed to git history

---

## POSITIVE SECURITY PRACTICES OBSERVED

1. **Strong Password Policy:** Pydantic validators enforce 8+ chars, uppercase, lowercase, digits
2. **Credential Encryption:** Fernet encryption for stored Proxmox/Cloudflare credentials
3. **2FA Support:** TOTP implementation for admin accounts
4. **JWT Authentication:** Proper token-based auth with refresh tokens
5. **Bcrypt Password Hashing:** Using secure bcrypt for password storage
6. **Input Validation:** Pydantic schemas validate most user inputs
7. **Prepared Statements:** SQLAlchemy ORM prevents SQL injection
8. **HTTPS Enforcement:** nginx redirects HTTP to HTTPS
9. **TLS 1.2+ Only:** Modern TLS configuration in nginx
10. **Secrets Module:** Used in `generate_random_password.py`
11. **Proper Gitignore:** .env files excluded from version control

---

## DEPENDENCY ANALYSIS

### Backend Python Dependencies
All packages appear reasonably current (2024-2025):
- ✓ FastAPI 0.115.0 (recent)
- ✓ SQLAlchemy 2.0.35 (latest stable)
- ✓ Pydantic settings 2.5.0 (current)
- ⚠ python-jose 3.3.0 (consider upgrading to python-jose[cryptography] latest)
- ⚠ passlib 1.7.4 (mature but old, still maintained)

### Frontend Dependencies (from package.json)
- ✓ React 18.2.0 (stable)
- ✓ MUI 5.15.15 (recent)
- ✓ Axios 1.6.8 (current)
- ✓ Vite 5.2.0 (modern build tool)

**Action Required:** Run `npm audit` with proper permissions to check for frontend CVEs.

---

## RISK SUMMARY

**Critical Risks (Immediate Action Required):**
1. Hardcoded secrets in config.py
2. SSL verification disabled
3. CORS wildcard with credentials

**High Risks (Address Within 1 Week):**
1. No authentication rate limiting
2. Missing security headers
3. Weak PRNG in cloud-init passwords
4. Deprecated datetime functions

**Medium Risks (Address Within 1 Month):**
1. Path traversal validation
2. Timeout configuration
3. Broad exception handling
4. Input sanitization improvements

---

## RECOMMENDATIONS PRIORITY

### Immediate (24-48 hours):
1. Change default SECRET_KEY and admin password in production
2. Restrict CORS to specific frontend origin
3. Enable SSL verification or document risks

### Short-term (1 week):
1. Implement rate limiting on auth endpoints
2. Add security headers to nginx
3. Replace random.choices with secrets in cloud-init
4. Update datetime.utcnow() to timezone-aware calls

### Medium-term (1 month):
1. Add comprehensive audit logging
2. Implement path validation for file operations
3. Configure HTTP client timeouts
4. Run dependency security scans (pip-audit, npm audit)
5. Add pre-commit hooks for secret detection

### Long-term (Ongoing):
1. Regular dependency updates
2. Penetration testing
3. Security code reviews
4. SIEM integration for audit logs

---

## TOOLS AVAILABILITY STATUS

**Available:**
- ✓ npm (for frontend scanning)
- ✓ python3 (for backend analysis)
- ✓ grep/regex pattern matching (manual scans completed)

**Not Available:**
- ✗ bandit (Python security linter)
- ✗ semgrep (multi-language security scanner)
- ✗ pip-audit (Python dependency CVE scanner)
- ✗ trivy (container/dependency scanner)
- ✗ detect-secrets (secret detection)

**Workaround:** Manual pattern analysis completed using grep/regex for common vulnerability patterns.

---

## NEXT STEPS

1. Review findings with development team
2. Prioritize remediation based on severity
3. Create tickets for each finding
4. Implement fixes following secure coding practices
5. Re-scan after remediation
6. Consider Phase 2: Manual code review and penetration testing

---

## UNRESOLVED QUESTIONS

1. Is .env file truly excluded from version control history? (run: `git log --all --full-history -- .env`)
2. What is the production SECRET_KEY rotation policy?
3. Are there any WAF/IDS systems in front of the application?
4. Is there a security incident response plan?
5. What is the patch management process for dependencies?
6. Are there automated security scans in CI/CD pipeline?
