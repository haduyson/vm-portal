# VM Portal Security Audit Report

**Date:** 2026-01-31
**Auditor:** Security Audit Team (Automated + Manual)
**Scope:** Full security assessment - Backend, Frontend, Infrastructure
**Classification:** Confidential

---

## Executive Summary

Comprehensive security audit of VM Portal identified **31 unique security findings** after deduplication across automated scanning, manual code review, and infrastructure review phases.

**Risk Rating: HIGH** - Multiple critical vulnerabilities requiring immediate remediation before production deployment.

### Key Critical Issues (Immediate Action Required):
1. **VNC WebSocket lacks authentication** - Any user can access any VM console
2. **Suspended users not blocked** - Can still authenticate and access resources
3. **CORS allows all origins** - CSRF attacks possible from any domain
4. **Database exposed to host** - Direct DB access bypasses application security
5. **Weak default credentials** - SECRET_KEY, admin password, DB password

### Positive Findings:
- Strong password policy (8+ chars, mixed case, digits)
- Bcrypt password hashing
- JWT authentication with refresh tokens
- Fernet encryption for stored credentials
- 2FA/TOTP support
- TLS 1.2+ enforcement
- HTTPS redirect configured

---

## Risk Summary

| Severity | Count | Response Time |
|----------|-------|---------------|
| Critical | 8 | Immediate |
| High | 10 | 24-48 hours |
| Medium | 10 | 1 week |
| Low | 3 | Next sprint |
| **Total** | **31** | |

### CVSS Distribution
- Critical (9.0-10.0): 8 findings
- High (7.0-8.9): 10 findings
- Medium (4.0-6.9): 10 findings
- Low (0.1-3.9): 3 findings

---

## Critical Findings

### [SEC-001] VNC WebSocket Lacks Authentication
- **CVSS:** 9.8 (Critical)
- **Component:** `backend/app/api/vnc-websocket-proxy-endpoint.py:65-88`
- **CWE:** CWE-306 (Missing Authentication)
- **Description:** VNC WebSocket endpoint accepts connections without JWT validation. No ownership verification.
- **Impact:** Any unauthenticated user can access any VM's console by guessing vmid.
- **Remediation:** Add JWT token validation and VM ownership check.
- **Phase Source:** Manual Code Review

### [SEC-002] Suspended Users Not Blocked
- **CVSS:** 9.1 (Critical)
- **Component:** `backend/app/core/security.py:110-138`
- **CWE:** CWE-285 (Improper Authorization)
- **Description:** `get_current_user` does not check `is_suspended` flag.
- **Impact:** Admin suspends malicious user but they retain full access.
- **Remediation:** Add `if user.is_suspended: raise HTTPException(403)`
- **Phase Source:** Manual Code Review

### [SEC-003] CORS Allows All Origins
- **CVSS:** 8.6 (Critical)
- **Component:** `backend/app/main.py:86`
- **CWE:** CWE-942 (Permissive Cross-domain Policy)
- **Description:** `allow_origins=["*"]` with `allow_credentials=True`
- **Impact:** CSRF attacks, token theft from malicious sites.
- **Remediation:** Restrict to specific frontend origins.
- **Phase Source:** Automated Scan + Manual Review

### [SEC-004] Weak Default SECRET_KEY
- **CVSS:** 9.3 (Critical)
- **Component:** `backend/app/config.py:9`
- **CWE:** CWE-798 (Hard-coded Credentials)
- **Description:** Default `SECRET_KEY = "change-me-in-production"`
- **Impact:** JWT token forgery, full authentication bypass.
- **Remediation:** Require from environment, validate strength on startup.
- **Phase Source:** Automated Scan + Manual Review

### [SEC-005] Database Exposed to Host Network
- **CVSS:** 9.0 (Critical)
- **Component:** `docker-compose.yml:15-16`
- **CWE:** CWE-284 (Improper Access Control)
- **Description:** PostgreSQL port 5432 mapped to host.
- **Impact:** Direct DB access bypassing application layer.
- **Remediation:** Remove port mapping, access via internal network only.
- **Phase Source:** Infrastructure Review

### [SEC-006] SSL Verification Disabled
- **CVSS:** 8.8 (Critical)
- **Component:** `backend/app/config.py:25`, `vnc-websocket-proxy-endpoint.py:25,46,146`
- **CWE:** CWE-295 (Improper Certificate Validation)
- **Description:** `PROXMOX_VERIFY_SSL=False`, `ssl.CERT_NONE`
- **Impact:** MITM attacks, credential interception.
- **Remediation:** Enable verification, allow custom CA cert.
- **Phase Source:** Automated Scan

### [SEC-007] AppArmor Disabled on All Containers
- **CVSS:** 8.4 (Critical)
- **Component:** `docker-compose.yml:5-6,28-29,47-48`
- **CWE:** CWE-250 (Unnecessary Privileges)
- **Description:** `apparmor:unconfined` on db, api, nginx containers.
- **Impact:** Containers bypass MAC restrictions if compromised.
- **Remediation:** Remove security_opt or use custom profiles.
- **Phase Source:** Infrastructure Review

### [SEC-008] Backend Container Running as Root
- **CVSS:** 8.2 (Critical)
- **Component:** `backend/Dockerfile`
- **CWE:** CWE-250 (Unnecessary Privileges)
- **Description:** No USER directive, runs as UID 0.
- **Impact:** Container escape grants root access to host.
- **Remediation:** Add non-root user with `RUN useradd && USER appuser`.
- **Phase Source:** Infrastructure Review

---

## High Severity Findings

### [SEC-009] No Rate Limiting on Authentication
- **CVSS:** 7.5 | **CWE:** CWE-307
- **Component:** `backend/app/api/auth_endpoints.py`, `nginx/nginx.conf`
- **Description:** No rate limiting or brute force protection.
- **Impact:** Credential stuffing, password brute force.
- **Remediation:** Implement slowapi/fastapi-limiter + nginx limit_req.

### [SEC-010] Missing Security Headers
- **CVSS:** 7.4 | **CWE:** CWE-693
- **Component:** `nginx/nginx.conf`
- **Description:** Missing X-Frame-Options, CSP, HSTS, X-Content-Type-Options.
- **Impact:** Clickjacking, XSS, MIME sniffing attacks.
- **Remediation:** Add all security headers to nginx.

### [SEC-011] API Port Exposed to Host
- **CVSS:** 7.3 | **CWE:** CWE-284
- **Component:** `docker-compose.yml:32-33`
- **Description:** Port 8000 exposed, bypasses nginx security.
- **Impact:** Direct API access without TLS, rate limiting.
- **Remediation:** Remove port mapping.

### [SEC-012] Weak Password Generation in Cloud-init
- **CVSS:** 7.2 | **CWE:** CWE-330
- **Component:** `backend/app/services/cloud_init_generator.py:189`
- **Description:** Using `random.choices()` instead of `secrets`.
- **Impact:** Predictable VM passwords.
- **Remediation:** Use `secrets` module.

### [SEC-013] Development Mode in Production
- **CVSS:** 6.8 | **CWE:** CWE-489
- **Component:** `backend/Dockerfile:12`
- **Description:** Uvicorn `--reload` flag in production.
- **Impact:** Performance overhead, potential debug exposure.
- **Remediation:** Remove `--reload`, add `--workers 4`.

### [SEC-014] JWT Uses HS256 (Symmetric)
- **CVSS:** 6.5 | **CWE:** CWE-327
- **Component:** `backend/app/config.py:11`
- **Description:** Single key for sign/verify.
- **Impact:** Key compromise = full auth bypass.
- **Remediation:** Migrate to RS256 (asymmetric).

### [SEC-015] Bcrypt Rounds Not Configured
- **CVSS:** 6.8 | **CWE:** CWE-916
- **Component:** `backend/app/core/security.py:16`
- **Description:** Using default ~10-12 rounds.
- **Impact:** Faster offline brute force if DB leaked.
- **Remediation:** Set `bcrypt__rounds=12`.

### [SEC-016] No Refresh Token Rotation on Failure
- **CVSS:** 6.2 | **CWE:** CWE-384
- **Component:** `backend/app/api/auth_endpoints.py:132-169`
- **Description:** Token not revoked on verification failure.
- **Impact:** Replay attack window.
- **Remediation:** Revoke on any failure.

### [SEC-017] Weak Default Database Credentials
- **CVSS:** 7.8 | **CWE:** CWE-798
- **Component:** `docker-compose.yml:8-10`
- **Description:** Fallback to `password` if env not set.
- **Impact:** Production deployments with weak credentials.
- **Remediation:** Fail startup if DB_PASSWORD not set.

### [SEC-018] Deprecated datetime.utcnow() Usage
- **CVSS:** 6.1 | **CWE:** CWE-477
- **Component:** Multiple files (9+ instances)
- **Description:** Deprecated in Python 3.12+.
- **Impact:** Future compatibility issues.
- **Remediation:** Use `datetime.now(timezone.utc)`.

---

## Medium Severity Findings

### [SEC-019] No HTTPS Enforcement in Backend
- **CVSS:** 5.9 | **CWE:** CWE-319
- Missing HTTPS redirect middleware and HSTS in FastAPI.

### [SEC-020] JWT Token Type Not Whitelisted
- **CVSS:** 5.4 | **CWE:** CWE-863
- Partial 2FA tokens blocked but edge cases exist.

### [SEC-021] VM Name Regex Allows Injection Patterns
- **CVSS:** 5.3 | **CWE:** CWE-20
- Allows double hyphens, trailing hyphens.

### [SEC-022] Cloud-init Shell Commands
- **CVSS:** 5.1 | **CWE:** CWE-78
- Potential injection if inputs not sanitized.

### [SEC-023] Email Templates Lack HTML Escaping
- **CVSS:** 4.7 | **CWE:** CWE-79
- XSS risk in email clients.

### [SEC-024] No Resource Limits on Containers
- **CVSS:** 5.5 | **CWE:** CWE-400
- No CPU/memory limits configured.

### [SEC-025] Host Filesystem Mounts (RW)
- **CVSS:** 5.0 | **CWE:** CWE-284
- Host paths mounted read-write unnecessarily.

### [SEC-026] Broad Exception Handling
- **CVSS:** 4.5 | **CWE:** CWE-755
- Generic `except Exception:` may hide security errors.

### [SEC-027] No Request Timeout Configuration
- **CVSS:** 5.3 | **CWE:** CWE-400
- aiohttp sessions without timeouts.

### [SEC-028] No CSRF Token Validation
- **CVSS:** 4.8 | **CWE:** CWE-352
- Relies on JWT-in-header (partial mitigation).

---

## Low Severity Findings

### [SEC-029] SSH AutoAddPolicy
- **CVSS:** 3.9 | **CWE:** CWE-295
- Accepts any SSH host key.

### [SEC-030] No Password Masking in Logs
- **CVSS:** 3.3 | **CWE:** CWE-532
- Potential credential leakage in logs.

### [SEC-031] Weak SSL Cipher Suite
- **CVSS:** 3.1 | **CWE:** CWE-326
- Missing ChaCha20 cipher.

---

## Remediation Timeline

### Phase 1: Immediate (24-48h)
| Priority | Finding | Effort |
|----------|---------|--------|
| 1 | SEC-001: VNC WebSocket auth | 2h |
| 2 | SEC-002: Suspended user check | 30m |
| 3 | SEC-003: Restrict CORS | 30m |
| 4 | SEC-004: Validate SECRET_KEY | 1h |
| 5 | SEC-005: Remove DB port | 10m |
| 6 | SEC-007: Re-enable AppArmor | 10m |

### Phase 2: Short-term (1 week)
| Priority | Finding | Effort |
|----------|---------|--------|
| 7 | SEC-009: Rate limiting | 3h |
| 8 | SEC-010: Security headers | 1h |
| 9 | SEC-011: Remove API port | 10m |
| 10 | SEC-012: Fix password generation | 30m |
| 11 | SEC-008: Non-root containers | 1h |
| 12 | SEC-013: Remove --reload | 10m |

### Phase 3: Medium-term (1 month)
| Priority | Finding | Effort |
|----------|---------|--------|
| 13 | SEC-006: SSL verification | 2h |
| 14 | SEC-015: Bcrypt rounds | 30m |
| 15 | SEC-017: DB credentials | 1h |
| 16 | SEC-019-028: Medium findings | 8h |

### Phase 4: Long-term (Ongoing)
| Priority | Finding | Effort |
|----------|---------|--------|
| 17 | SEC-014: RS256 migration | 4h |
| 18 | SEC-029-031: Low findings | 2h |
| - | Regular dependency updates | Ongoing |
| - | Security code reviews | Ongoing |

---

## Compliance Checklist Status

| Control | Status | Notes |
|---------|--------|-------|
| Authentication | PARTIAL | Missing suspended check, rate limiting |
| Authorization | PARTIAL | VNC lacks ownership check |
| Input Validation | PARTIAL | Some regex gaps |
| Session Management | PASS | JWT with refresh tokens |
| Password Storage | PASS | Bcrypt (rounds need config) |
| Transport Security | PARTIAL | Missing HSTS, headers |
| CORS Policy | FAIL | Wildcard origin |
| Rate Limiting | FAIL | Not implemented |
| Container Security | FAIL | Root users, no limits |
| Secret Management | PARTIAL | Defaults in code |

---

## Unresolved Questions

1. Is DB port 5432 exposure required for external admin tools?
2. What is production SECRET_KEY rotation policy?
3. Are WAF/IDS systems in place?
4. What is max file upload size requirement?
5. Are host mounts required read-write in production?
6. Is there a security incident response plan?

---

## Next Steps

1. **Immediate:** Share report with development team
2. **This week:** Create tickets for Phase 1+2 findings
3. **Next sprint:** Implement Phase 1+2 remediations
4. **Month 1:** Complete Phase 3 remediations
5. **Month 2:** Re-audit to verify fixes
6. **Ongoing:** Schedule quarterly security reviews

---

**Report Generated:** 2026-01-31
**Classification:** Confidential
**Distribution:** Development Team, Security Team, Management
