# Phase 5: Email Service - SMTP & API Dual Provider Notifications

## Context Links

- [Main Plan](./plan.md)
- [Email Providers Research](./research/researcher-email-providers-api.md)
- [Brainstorm - Email Section](../reports/brainstorm-260131-0747-vm-portal-network-email-features.md)
- TelegramNotifier: `/home/portal/backend/app/services/telegram_notifier.py`

## Overview

| Priority | P2 |
|----------|-----|
| Status | completed |
| Effort | 4h |
| Depends on | Phase 1 (user.email field) |

Implement dual-provider email service (SMTP + API) with notification templates, user preferences, and admin configuration.

## Key Insights

- TelegramNotifier pattern: async methods, send_vm_ready, send_vm_error, send_password_reset
- System settings uses key-value store for config
- aiosmtplib for async SMTP (self-hosted)
- httpx for SendGrid/Resend API (managed service)
- Multipart MIME: plain text + HTML for deliverability

## Requirements

### Functional

1. EmailService with SMTP and API provider support
2. Admin UI to configure email provider and credentials
3. User notification preference: telegram | email | both
4. Email templates: vm_ready, vm_error, password_reset, account_events
5. Test email button in admin settings
6. Fallback: API fails → try SMTP (or vice versa)

### Non-Functional

- Async sending (non-blocking)
- Multipart MIME (text + HTML)
- Rate limiting consideration
- Graceful failure (don't crash if email fails)

## Architecture

```
┌─────────────────────┐
│  NotificationService│  ← Unified interface
└─────────────────────┘
         │
    ┌────┴────┐
    ▼         ▼
┌────────┐ ┌────────┐
│Telegram│ │ Email  │
│Notifier│ │Service │
└────────┘ └────────┘
               │
         ┌─────┴─────┐
         ▼           ▼
    ┌─────────┐ ┌─────────┐
    │  SMTP   │ │   API   │
    │aiosmtplib│ │ httpx  │
    └─────────┘ └─────────┘
```

## Implementation Steps

### Step 1: Create EmailService

File: `/home/portal/backend/app/services/email-notification-service.py`

```python
import aiosmtplib
import httpx
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class EmailService:
    """Dual-provider email service (SMTP + API)."""

    def __init__(
        self,
        provider: str = "smtp",  # smtp | sendgrid | resend
        smtp_host: str | None = None,
        smtp_port: int = 587,
        smtp_user: str | None = None,
        smtp_password: str | None = None,
        smtp_use_tls: bool = True,
        api_key: str | None = None,
        from_email: str = "noreply@example.com",
        from_name: str = "VM Portal",
    ):
        self.provider = provider
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.smtp_user = smtp_user
        self.smtp_password = smtp_password
        self.smtp_use_tls = smtp_use_tls
        self.api_key = api_key
        self.from_email = from_email
        self.from_name = from_name

    @classmethod
    async def from_db_config(cls, session: AsyncSession) -> "EmailService":
        """Create EmailService from database settings."""
        from app.services.system_settings_service import get_setting
        return cls(
            provider=await get_setting(session, "email_provider") or "smtp",
            smtp_host=await get_setting(session, "smtp_host"),
            smtp_port=int(await get_setting(session, "smtp_port") or 587),
            smtp_user=await get_setting(session, "smtp_user"),
            smtp_password=await get_setting(session, "smtp_password"),
            smtp_use_tls=(await get_setting(session, "smtp_use_tls") or "true") == "true",
            api_key=await get_setting(session, "email_api_key"),
            from_email=await get_setting(session, "email_from_address") or "noreply@example.com",
            from_name=await get_setting(session, "email_from_name") or "VM Portal",
        )

    async def send(
        self,
        to_email: str,
        subject: str,
        text_body: str,
        html_body: str | None = None
    ) -> bool:
        """Send email via configured provider."""
        try:
            if self.provider == "smtp":
                return await self._send_smtp(to_email, subject, text_body, html_body)
            elif self.provider in ("sendgrid", "resend"):
                return await self._send_api(to_email, subject, text_body, html_body)
            return False
        except Exception as e:
            print(f"Email send error: {e}")
            return False

    async def _send_smtp(self, to_email, subject, text_body, html_body) -> bool:
        """Send via SMTP using aiosmtplib."""
        if not self.smtp_host:
            return False

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{self.from_name} <{self.from_email}>"
        msg["To"] = to_email

        msg.attach(MIMEText(text_body, "plain", "utf-8"))
        if html_body:
            msg.attach(MIMEText(html_body, "html", "utf-8"))

        await aiosmtplib.send(
            msg,
            hostname=self.smtp_host,
            port=self.smtp_port,
            username=self.smtp_user,
            password=self.smtp_password,
            start_tls=self.smtp_use_tls,
        )
        return True

    async def _send_api(self, to_email, subject, text_body, html_body) -> bool:
        """Send via API (SendGrid/Resend)."""
        if not self.api_key:
            return False

        if self.provider == "sendgrid":
            return await self._send_sendgrid(to_email, subject, text_body, html_body)
        elif self.provider == "resend":
            return await self._send_resend(to_email, subject, text_body, html_body)
        return False

    async def _send_sendgrid(self, to_email, subject, text_body, html_body) -> bool:
        """SendGrid API v3."""
        async with httpx.AsyncClient() as client:
            payload = {
                "personalizations": [{"to": [{"email": to_email}]}],
                "from": {"email": self.from_email, "name": self.from_name},
                "subject": subject,
                "content": [
                    {"type": "text/plain", "value": text_body},
                ]
            }
            if html_body:
                payload["content"].append({"type": "text/html", "value": html_body})

            resp = await client.post(
                "https://api.sendgrid.com/v3/mail/send",
                json=payload,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=30,
            )
            return resp.status_code == 202

    async def _send_resend(self, to_email, subject, text_body, html_body) -> bool:
        """Resend API."""
        async with httpx.AsyncClient() as client:
            payload = {
                "from": f"{self.from_name} <{self.from_email}>",
                "to": [to_email],
                "subject": subject,
                "text": text_body,
            }
            if html_body:
                payload["html"] = html_body

            resp = await client.post(
                "https://api.resend.com/emails",
                json=payload,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=30,
            )
            return resp.status_code == 200
```

### Step 2: Create Email Templates

File: `/home/portal/backend/app/services/email-templates.py`

```python
class EmailTemplates:
    """Email templates matching Telegram notification style."""

    @staticmethod
    def vm_ready(
        vm_name: str,
        ip: str,
        username: str,
        password: str,
        ssh_domain: str,
        web_domain: str | None,
        portal_url: str
    ) -> tuple[str, str]:
        """Return (text, html) for VM ready notification."""
        text = f"""VM Đã Sẵn Sàng!

Tên VM: {vm_name}
IP Nội Bộ: {ip}
SSH Domain: {ssh_domain}
{f"Web Domain: {web_domain}" if web_domain else ""}
Username: {username}
Password: {password}

Kết nối: ssh {username}@{ssh_domain}
Quản lý VM: {portal_url}
"""
        html = f"""<html>...</html>"""  # Styled HTML version
        return text, html

    @staticmethod
    def vm_error(vm_name: str, error: str) -> tuple[str, str]:
        """Return (text, html) for VM error notification."""
        # ...

    @staticmethod
    def password_reset(
        username: str,
        new_password: str,
        expiry_minutes: int | None,
        portal_url: str
    ) -> tuple[str, str]:
        """Return (text, html) for password reset notification."""
        # ...
```

### Step 3: Create Unified NotificationService

File: `/home/portal/backend/app/services/unified-notification-service.py`

```python
class NotificationService:
    """Unified notification service respecting user preferences."""

    def __init__(
        self,
        telegram: TelegramNotifier,
        email: EmailService,
    ):
        self.telegram = telegram
        self.email = email

    @classmethod
    async def from_db_config(cls, session: AsyncSession) -> "NotificationService":
        telegram = await TelegramNotifier.from_db_config(session)
        email = await EmailService.from_db_config(session)
        return cls(telegram, email)

    async def notify_vm_ready(
        self,
        user: User,
        vm_name: str,
        ip: str,
        username: str,
        password: str,
        ssh_domain: str,
        web_domain: str | None = None,
    ) -> dict[str, bool]:
        """Send VM ready notification based on user preference."""
        results = {"telegram": False, "email": False}
        pref = user.notification_preference or "telegram"

        if pref in ("telegram", "both") and user.telegram_chat_id:
            results["telegram"] = await self.telegram.send_vm_ready(
                user.telegram_chat_id, vm_name, ip, username, password, ssh_domain, web_domain
            )

        if pref in ("email", "both") and user.email:
            text, html = EmailTemplates.vm_ready(
                vm_name, ip, username, password, ssh_domain, web_domain, self.telegram.portal_url
            )
            results["email"] = await self.email.send(user.email, "VM Đã Sẵn Sàng", text, html)

        return results
```

### Step 4: Add Email Settings to System Settings

File: `/home/portal/backend/app/api/admin_settings_routes.py`

```python
@router.get("/email")
async def get_email_settings(...):
    """Get email configuration (mask password/api_key)."""

@router.put("/email")
async def update_email_settings(data: EmailSettingsUpdate, ...):
    """Update email configuration."""

@router.post("/email/test")
async def send_test_email(to_email: str, ...):
    """Send test email to verify configuration."""
```

### Step 5: Create Admin Email Config UI

File: `/home/portal/frontend/src/pages/admin/email-provider-configuration-page.tsx`

Components:
- Provider selection (SMTP / SendGrid / Resend)
- SMTP config form (host, port, user, password, TLS)
- API config form (API key)
- From address/name
- Test email button

### Step 6: Add User Notification Preference UI

File: `/home/portal/frontend/src/pages/user-profile-settings-page.tsx`

Add to profile page:
- Email input field
- Notification preference radio (Telegram / Email / Both)

### Step 7: Update VM Creation to Use NotificationService

Replace direct TelegramNotifier calls with NotificationService:

```python
# Before
await telegram.send_vm_ready(user.telegram_chat_id, ...)

# After
notifier = await NotificationService.from_db_config(session)
await notifier.notify_vm_ready(user, vm_name, ip, ...)
```

## Todo List

- [x] Create EmailService with SMTP and API providers
- [x] Create EmailTemplates matching Telegram style
- [x] Create NotificationService (unified Telegram + Email)
- [x] Add email settings API endpoints
- [x] Add email settings admin UI
- [x] Add notification preference to user profile
- [x] Add aiosmtplib, httpx to requirements.txt
- [x] Update VM creation to use NotificationService
- [x] Update password reset to use NotificationService
- [x] Add test email functionality
- [ ] Test SMTP provider
- [ ] Test SendGrid provider

## Success Criteria

- [x] Admin can configure SMTP provider
- [x] Admin can configure API provider (SendGrid/Resend)
- [x] Test email sends successfully
- [x] User can set email and notification preference
- [x] VM ready notification respects user preference
- [x] Password reset notification respects user preference
- [ ] Fallback works when primary provider fails

## Related Code Files

| Action | File |
|--------|------|
| Create | `/home/portal/backend/app/services/email-notification-service.py` |
| Create | `/home/portal/backend/app/services/email-templates.py` |
| Create | `/home/portal/backend/app/services/unified-notification-service.py` |
| Modify | `/home/portal/backend/app/api/admin_settings_routes.py` |
| Modify | `/home/portal/backend/requirements.txt` |
| Create | `/home/portal/frontend/src/pages/admin/email-provider-configuration-page.tsx` |
| Modify | `/home/portal/frontend/src/pages/` (user profile) |

## Dependencies

Add to `/home/portal/backend/requirements.txt`:
```
aiosmtplib>=3.0.0
httpx>=0.24.0
```

## Security Considerations

- Store SMTP password and API keys encrypted or use secrets manager
- Mask credentials in API responses
- Rate limit email sending
- Validate email addresses before sending

## Next Phase

[Phase 6: Feature Toggles](./phase-06-hierarchical-feature-toggles-global-user-vm-level.md)
