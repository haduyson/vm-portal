# Phase 4: User IP Pool - Acquire, Retain & Static Assignment

## Context Links

- [Main Plan](./plan.md)
- [Phase 3: Network Selection](./phase-03-vm-creation-form-network-bridge-vlan-selection.md)
- [Brainstorm - IP Pool Section](../reports/brainstorm-260131-0747-vm-portal-network-email-features.md)
- Cloud-init: `/home/portal/backend/app/services/cloud_init_generator.py`

## Overview

| Priority | P2 |
|----------|-----|
| Status | completed |
| Effort | 4h |
| Depends on | Phase 1, Phase 3 |

Implement user-owned IP pool: auto-acquire on VM creation, retain option on deletion, static IP assignment for new VMs.

## Key Insights

- Current: VM gets IP via DHCP, stored in `ip_address` field
- Current: `ipconfig0="ip=dhcp"` in cloud-init config
- Static IP: `ipconfig0=ip=192.168.1.100/24,gw=192.168.1.1`
- Only public network bridges should track IP ownership
- User can retain IP when deleting VM → reuse for new VM

## Requirements

### Functional

1. Auto-acquire: When VM gets IP on public bridge, create ownership record
2. Retain option: VM delete dialog asks "Keep IP address?"
3. IP selection: VM create shows user's available IPs from pool
4. Static assignment: Selected IP configured via cloud-init
5. IP release: Non-retained IPs returned to DHCP pool

### Non-Functional

- IP detection via QEMU guest agent (existing mechanism)
- Unique constraint prevents duplicate IP ownership

## Architecture

```
VM Creation (DHCP)                    VM Creation (Static IP)
       │                                      │
       ▼                                      ▼
┌─────────────────┐                  ┌─────────────────┐
│ VM boots, gets  │                  │ User selects IP │
│ IP from DHCP    │                  │ from their pool │
└─────────────────┘                  └─────────────────┘
       │                                      │
       ▼                                      ▼
┌─────────────────┐                  ┌─────────────────┐
│ Portal detects  │                  │ Cloud-init with │
│ IP via agent    │                  │ ipconfig0=static│
└─────────────────┘                  └─────────────────┘
       │                                      │
       ▼                                      │
┌─────────────────┐                           │
│ If public bridge│                           │
│ → Create        │                           │
│ user_ip_addresses│                          │
│ record          │                           │
└─────────────────┘                           │
       │                                      │
       └──────────────────────────────────────┘
                         │
                         ▼
              ┌─────────────────────┐
              │  VM Deletion        │
              │  Keep IP? Yes/No    │
              └─────────────────────┘
                    │         │
           Yes ─────┘         └───── No
                    │                  │
                    ▼                  ▼
          ┌────────────────┐  ┌────────────────┐
          │ vm_id = NULL   │  │ Delete record  │
          │ is_retained=T  │  │ IP returns to  │
          └────────────────┘  │ DHCP pool      │
                              └────────────────┘
```

## Implementation Steps

### Step 1: Create UserIpAddressService

File: `/home/portal/backend/app/services/user-ip-address-service.py`

```python
class UserIpAddressService:
    @staticmethod
    async def acquire_ip(
        session: AsyncSession,
        user_id: int,
        ip_address: str,
        network_bridge_id: int,
        vm_id: int,
        subnet_mask: str = "255.255.255.0",
        gateway: str | None = None
    ) -> UserIpAddress:
        """Create IP ownership record when VM acquires IP on public network."""

    @staticmethod
    async def get_user_available_ips(
        session: AsyncSession,
        user_id: int,
        network_bridge_id: int | None = None
    ) -> list[UserIpAddress]:
        """Get user's IPs not assigned to any VM (vm_id is NULL)."""

    @staticmethod
    async def assign_ip_to_vm(
        session: AsyncSession,
        ip_id: int,
        vm_id: int
    ) -> UserIpAddress:
        """Assign an available IP to a VM."""

    @staticmethod
    async def release_ip(
        session: AsyncSession,
        vm_id: int,
        retain: bool = False
    ) -> None:
        """Release IP when VM deleted. If retain=True, keep record with vm_id=NULL."""

    @staticmethod
    async def check_ip_exists(session: AsyncSession, ip_address: str) -> bool:
        """Check if IP already owned by any user."""
```

### Step 2: Create IP Pool Schemas

File: `/home/portal/backend/app/schemas/user-ip-address-schema.py`

```python
class UserIpAddressResponse(BaseModel):
    id: int
    ip_address: str
    subnet_mask: str
    gateway: str | None
    network_bridge_id: int
    bridge_name: str  # Joined from network_bridges
    vm_id: int | None
    vm_name: str | None  # Joined from virtual_machines
    is_retained: bool
    acquired_at: datetime

class IpSelectionOption(BaseModel):
    """For VM create form dropdown"""
    id: int
    ip_address: str
    gateway: str | None
    subnet_mask: str

class VMDeleteRequest(BaseModel):
    retain_ip: bool = False  # Keep IP in user's pool
```

### Step 3: Update VM Status Polling to Acquire IP

File: `/home/portal/backend/app/services/vm_service.py` (or equivalent)

Modify IP detection logic:

```python
async def update_vm_ip(session: AsyncSession, vm: VirtualMachine, ip_address: str):
    """Update VM IP and create ownership record if public network."""
    vm.ip_address = ip_address

    # Check if bridge is public network
    if vm.network_bridge_id:
        bridge = await session.get(NetworkBridge, vm.network_bridge_id)
        if bridge and bridge.is_public_network:
            # Check if IP not already owned
            if not await UserIpAddressService.check_ip_exists(session, ip_address):
                await UserIpAddressService.acquire_ip(
                    session,
                    user_id=vm.user_id,
                    ip_address=ip_address,
                    network_bridge_id=vm.network_bridge_id,
                    vm_id=vm.id,
                    gateway=bridge.gateway  # If stored
                )

    await session.commit()
```

### Step 4: Update VM Deletion with Retain Option

File: `/home/portal/backend/app/api/vm_routes.py`

```python
@router.delete("/{vm_id}")
async def delete_vm(
    vm_id: int,
    retain_ip: bool = Query(False, description="Keep IP in user's pool"),
    ...
):
    """Delete VM with option to retain public IP."""
    # ... existing validation ...

    # Release IP with retain option
    await UserIpAddressService.release_ip(session, vm_id, retain=retain_ip)

    # ... existing deletion logic ...
```

### Step 5: Update Cloud-Init for Static IP

File: `/home/portal/backend/app/services/cloud_init_generator.py`

Add method for static IP configuration:

```python
@staticmethod
def generate_ipconfig0(
    ip_source: str,  # "dhcp" or "static"
    ip_address: str | None = None,
    subnet_mask: str | None = None,
    gateway: str | None = None
) -> str:
    """Generate Proxmox ipconfig0 parameter."""
    if ip_source == "dhcp" or not ip_address:
        return "ip=dhcp"

    # Convert subnet mask to CIDR
    cidr = subnet_mask_to_cidr(subnet_mask or "255.255.255.0")
    config = f"ip={ip_address}/{cidr}"

    if gateway:
        config += f",gw={gateway}"

    return config
```

### Step 6: Add User IP Pool API Endpoints

File: `/home/portal/backend/app/api/user-ip-pool-router.py`

```python
router = APIRouter(prefix="/api/my-ips", tags=["IP Pool"])

@router.get("/")
async def list_my_ips(current_user: User = Depends(...)):
    """List all IPs owned by current user."""

@router.get("/available")
async def list_available_ips(
    network_bridge_id: int | None = None,
    current_user: User = Depends(...)
):
    """List user's available IPs (not assigned to VM)."""

@router.delete("/{ip_id}")
async def release_ip(ip_id: int, current_user: User = Depends(...)):
    """Permanently release an IP (remove ownership)."""
```

### Step 7: Update VM Create Form with IP Selection

File: `/home/portal/frontend/src/pages/` (VM create form)

Add IP source selection:

```tsx
// State
const [ipSource, setIpSource] = useState<'dhcp' | 'pool'>('dhcp');
const [availableIps, setAvailableIps] = useState<IpOption[]>([]);
const [selectedIpId, setSelectedIpId] = useState<number | null>(null);

// Fetch available IPs when bridge changes
useEffect(() => {
  if (selectedBridge) {
    fetchAvailableIps(selectedBridge);
  }
}, [selectedBridge]);

// Form fields
<FormControl>
  <FormLabel>IP Source</FormLabel>
  <RadioGroup value={ipSource} onChange={(e) => setIpSource(e.target.value)}>
    <FormControlLabel value="dhcp" label="DHCP (Auto-assign)" />
    <FormControlLabel
      value="pool"
      label="My IP Pool"
      disabled={availableIps.length === 0}
    />
  </RadioGroup>
</FormControl>

{ipSource === 'pool' && (
  <Select value={selectedIpId} onChange={...}>
    {availableIps.map(ip => (
      <MenuItem key={ip.id} value={ip.id}>
        {ip.ip_address} ({ip.gateway || 'No gateway'})
      </MenuItem>
    ))}
  </Select>
)}
```

### Step 8: Update VM Delete Dialog with Retain Option

File: `/home/portal/frontend/src/components/` (VM delete dialog)

```tsx
<Dialog>
  <DialogTitle>Xóa máy ảo {vm.name}?</DialogTitle>
  <DialogContent>
    {vm.ip_address && bridge?.is_public_network && (
      <FormControlLabel
        control={<Checkbox checked={retainIp} onChange={...} />}
        label={`Giữ lại IP ${vm.ip_address} trong danh sách IP của tôi`}
      />
    )}
  </DialogContent>
  <DialogActions>
    <Button onClick={() => deleteVm(vm.id, retainIp)}>Xóa</Button>
  </DialogActions>
</Dialog>
```

## Todo List

- [x] Create UserIpAddressService with acquire, release, assign methods
- [x] Create Pydantic schemas for IP pool operations
- [x] Update VM IP detection to create ownership records
- [x] Update VM deletion API with retain_ip parameter
- [x] Add generate_ipconfig0() for static IP cloud-init
- [x] Create /api/my-ips endpoints
- [x] Update VM create form with IP source selection
- [x] Update VM delete dialog with retain option
- [x] Add "My IPs" page to user dashboard
- [ ] Test DHCP → acquire flow
- [ ] Test retain → reuse flow
- [ ] Test static IP assignment

## Success Criteria

- [ ] VM on public bridge auto-creates IP ownership record
- [ ] User can see their IP pool in dashboard
- [ ] VM delete with retain=true keeps IP available
- [ ] VM delete with retain=false removes IP record
- [ ] VM create can select IP from user's pool
- [ ] Static IP correctly configured via ipconfig0
- [ ] IP unique constraint prevents duplicates

## Related Code Files

| Action | File |
|--------|------|
| Create | `/home/portal/backend/app/services/user-ip-address-service.py` |
| Create | `/home/portal/backend/app/schemas/user-ip-address-schema.py` |
| Create | `/home/portal/backend/app/api/user-ip-pool-router.py` |
| Modify | `/home/portal/backend/app/services/cloud_init_generator.py` |
| Modify | `/home/portal/backend/app/api/vm_routes.py` |
| Modify | `/home/portal/frontend/src/pages/` (VM create, delete) |
| Create | `/home/portal/frontend/src/pages/user-ip-pool-management-page.tsx` |

## Security Considerations

- Validate IP belongs to current user before assignment
- Validate IP is available (vm_id is NULL) before assignment
- Admin can manage any user's IPs; users only their own

## Next Phase

[Phase 5: Email Service](./phase-05-email-service-smtp-api-dual-provider-notifications.md)
