# Phase 2: Proxmox Network API - Bridge Discovery & Admin UI

## Context Links

- [Main Plan](./plan.md)
- [Phase 1: Database](./phase-01-database-migrations-network-bridges-ip-pool-email-fields.md)
- [Proxmox Network Research](./research/researcher-proxmox-network-vlan.md)
- ProxmoxService: `/home/portal/backend/app/services/proxmox_client.py`

## Overview

| Priority | P1 |
|----------|-----|
| Status | pending |
| Effort | 4h |
| Depends on | Phase 1 |

Implement Proxmox network API integration to discover bridges and build admin UI for bridge management.

## Key Insights

- Proxmox API: `GET /nodes/{node}/network` returns all interfaces
- Filter by `type: bridge` to get bridges only
- API may have filtering issues in v8.4.0+ - fallback to manual filtering
- vlan-aware bridges support `tag` and `trunks` parameters

## Requirements

### Functional

1. ProxmoxService fetches bridges from Proxmox API
2. Admin can view discovered bridges per server
3. Admin can enable/disable bridges for VM creation
4. Admin can set VLAN range restrictions per bridge
5. Admin can mark bridge as public network (for IP ownership)

### Non-Functional

- Cache bridge list (5 min TTL) to reduce API calls
- Handle Proxmox API errors gracefully

## Architecture

```
┌─────────────────┐     GET /nodes/{node}/network     ┌──────────────┐
│ ProxmoxService  │ ─────────────────────────────────>│  Proxmox VE  │
└─────────────────┘                                   └──────────────┘
        │
        ▼
┌─────────────────┐     POST /admin/bridges/sync
│  BridgeService  │<────────────────────────────────── Admin UI
└─────────────────┘
        │
        ▼
┌─────────────────┐
│ network_bridges │
│     (DB)        │
└─────────────────┘
```

## Implementation Steps

### Step 1: Add get_network_bridges to ProxmoxService

File: `/home/portal/backend/app/services/proxmox_client.py`

```python
async def get_network_bridges(self) -> list[dict]:
    """Fetch network bridges from Proxmox node."""
    def _get():
        try:
            interfaces = self.proxmox.nodes(self.node).network.get()
            bridges = [
                {
                    "iface": iface.get("iface"),
                    "type": iface.get("type"),
                    "address": iface.get("address"),
                    "gateway": iface.get("gateway"),
                    "bridge_ports": iface.get("bridge_ports"),
                    "bridge_vlan_aware": iface.get("bridge_vlan_aware", False),
                    "autostart": iface.get("autostart", 0),
                }
                for iface in interfaces
                if iface.get("type") == "bridge"
            ]
            return bridges
        except Exception as e:
            print(f"Error fetching bridges: {e}")
            return []
    return await asyncio.to_thread(_get)
```

### Step 2: Create NetworkBridgeService

File: `/home/portal/backend/app/services/network-bridge-service.py`

```python
class NetworkBridgeService:
    @staticmethod
    async def sync_bridges(session: AsyncSession, server_id: int) -> list[dict]:
        """Sync bridges from Proxmox to database."""
        # 1. Fetch from Proxmox API
        # 2. Upsert to network_bridges table
        # 3. Mark removed bridges as disabled

    @staticmethod
    async def get_bridges_for_server(session: AsyncSession, server_id: int) -> list:
        """Get all bridges for a server."""

    @staticmethod
    async def update_bridge(session: AsyncSession, bridge_id: int, data: dict) -> NetworkBridge:
        """Update bridge settings (vlan_min, vlan_max, is_enabled, etc.)."""

    @staticmethod
    async def get_enabled_bridges(session: AsyncSession, server_id: int) -> list:
        """Get enabled bridges for VM creation dropdown."""
```

### Step 3: Create Bridge Schemas

File: `/home/portal/backend/app/schemas/network-bridge-schema.py`

```python
class NetworkBridgeBase(BaseModel):
    bridge_name: str
    display_name: str | None = None
    vlan_min: int | None = None
    vlan_max: int | None = None
    is_public_network: bool = False
    is_enabled: bool = True

class NetworkBridgeResponse(NetworkBridgeBase):
    id: int
    proxmox_server_id: int
    created_at: datetime

class NetworkBridgeUpdate(BaseModel):
    display_name: str | None = None
    vlan_min: int | None = None
    vlan_max: int | None = None
    is_public_network: bool | None = None
    is_enabled: bool | None = None

class ProxmoxBridgeDiscovery(BaseModel):
    """Bridge info from Proxmox API"""
    iface: str
    address: str | None
    gateway: str | None
    bridge_vlan_aware: bool
```

### Step 4: Create Admin Bridge API Endpoints

File: `/home/portal/backend/app/api/admin-network-bridges-router.py`

```python
router = APIRouter(prefix="/admin/proxmox-servers/{server_id}/bridges", tags=["Admin Bridges"])

@router.post("/sync")
async def sync_bridges(server_id: int, ...):
    """Sync bridges from Proxmox API to database."""

@router.get("/")
async def list_bridges(server_id: int, ...):
    """List all bridges for a server."""

@router.get("/discovered")
async def discover_bridges(server_id: int, ...):
    """Fetch bridges directly from Proxmox (no DB)."""

@router.put("/{bridge_id}")
async def update_bridge(bridge_id: int, data: NetworkBridgeUpdate, ...):
    """Update bridge settings."""
```

### Step 5: Create Admin Bridge Management UI

File: `/home/portal/frontend/src/pages/admin/proxmox-server-bridges-management-page.tsx`

Components needed:
- Bridge list table with enable/disable toggle
- VLAN range input (min/max)
- Public network checkbox
- Sync button to refresh from Proxmox
- Display name editor

### Step 6: Integrate into Proxmox Server Settings

Add "Network Bridges" tab to existing Proxmox Server detail page.

## Todo List

- [ ] Add `get_network_bridges()` to ProxmoxService
- [ ] Create NetworkBridgeService with sync, get, update methods
- [ ] Create Pydantic schemas for bridge operations
- [ ] Create admin API router for bridge management
- [ ] Add Bridge management UI component
- [ ] Integrate into Proxmox Server settings page
- [ ] Add sync button with loading state
- [ ] Test with real Proxmox server

## Success Criteria

- [ ] `GET /admin/proxmox-servers/{id}/bridges/discovered` returns bridges from Proxmox
- [ ] `POST /admin/proxmox-servers/{id}/bridges/sync` upserts bridges to DB
- [ ] Admin can enable/disable bridges in UI
- [ ] Admin can set VLAN min/max restrictions
- [ ] Admin can mark bridge as public network
- [ ] Bridges persist across server restarts

## Related Code Files

| Action | File |
|--------|------|
| Modify | `/home/portal/backend/app/services/proxmox_client.py` |
| Create | `/home/portal/backend/app/services/network-bridge-service.py` |
| Create | `/home/portal/backend/app/schemas/network-bridge-schema.py` |
| Create | `/home/portal/backend/app/api/admin-network-bridges-router.py` |
| Modify | `/home/portal/backend/app/main.py` (register router) |
| Create | `/home/portal/frontend/src/pages/admin/proxmox-server-bridges-management-page.tsx` |

## Security Considerations

- Bridge management admin-only (require is_admin check)
- Validate VLAN ranges (1-4094)
- Don't expose Proxmox credentials in API responses

## Next Phase

[Phase 3: VM Creation with Network Selection](./phase-03-vm-creation-form-network-bridge-vlan-selection.md)
