# Phase 6: Hierarchical Feature Toggles - Global, User & VM Level

## Context Links

- [Main Plan](./plan.md)
- [Brainstorm - Feature Toggles](../reports/brainstorm-260131-0747-vm-portal-network-email-features.md)
- System Settings: `/home/portal/backend/app/models/system_settings_model.py`
- User Model: `/home/portal/backend/app/models/user_model.py`

## Overview

| Priority | P3 |
|----------|-----|
| Status | completed |
| Effort | 4h |
| Depends on | Phase 1 (feature_flags columns) |

Implement 3-level feature toggle system: Global → User → VM, where lower levels can override higher levels.

## Key Insights

- System settings already uses key-value store
- User and VM models have `feature_flags` JSON column (from Phase 1)
- Resolution: VM value > User value > Global value > Default
- Features: cloudflare_tunnel, public_ip, email_notifications, telegram_notifications

## Requirements

### Functional

1. Global toggles in system settings (admin only)
2. Per-user toggles (admin can override for specific users)
3. Per-VM toggles (user can override for specific VMs)
4. Toggle resolution respects hierarchy
5. UI shows inherited value when not overridden

### Non-Functional

- Fast resolution (no extra DB queries if possible)
- Clear UI indicating which level sets the value

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     Feature Resolution                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Level 3 (VM)     │ feature_flags: {"public_ip": false}        │ ← Highest priority
│                   │         ↓ if null                           │
│  Level 2 (User)   │ feature_flags: {"public_ip": true}         │
│                   │         ↓ if null                           │
│  Level 1 (Global) │ system_settings: global_feature_flags      │
│                   │         ↓ if null                           │
│  Default          │ Hardcoded defaults (all enabled)           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Feature Flag Definitions

| Feature | Key | Default | Description |
|---------|-----|---------|-------------|
| Cloudflare Tunnel | `cloudflare_tunnel_enabled` | true | Allow SSH subdomain creation |
| Public IP | `public_ip_enabled` | true | Allow public IP assignment |
| Email Notifications | `email_notifications_enabled` | true | Send email notifications |
| Telegram Notifications | `telegram_notifications_enabled` | true | Send Telegram notifications |

## Implementation Steps

### Step 1: Create FeatureFlagService

File: `/home/portal/backend/app/services/feature-flag-resolution-service.py`

```python
from typing import Any
from sqlalchemy.ext.asyncio import AsyncSession

# Default values for all features
FEATURE_DEFAULTS = {
    "cloudflare_tunnel_enabled": True,
    "public_ip_enabled": True,
    "email_notifications_enabled": True,
    "telegram_notifications_enabled": True,
}

class FeatureFlagService:
    """3-level feature flag resolution: VM > User > Global > Default."""

    @staticmethod
    async def get_global_flags(session: AsyncSession) -> dict:
        """Get global feature flags from system settings."""
        from app.services.system_settings_service import get_setting
        import json
        flags_json = await get_setting(session, "global_feature_flags")
        if flags_json:
            try:
                return json.loads(flags_json)
            except json.JSONDecodeError:
                pass
        return {}

    @staticmethod
    async def set_global_flags(session: AsyncSession, flags: dict) -> None:
        """Set global feature flags."""
        from app.services.system_settings_service import set_setting
        import json
        await set_setting(session, "global_feature_flags", json.dumps(flags))

    @staticmethod
    def resolve_flag(
        feature: str,
        global_flags: dict | None = None,
        user_flags: dict | None = None,
        vm_flags: dict | None = None,
    ) -> bool:
        """Resolve feature flag value. VM > User > Global > Default."""
        # Level 3: VM override
        if vm_flags and feature in vm_flags:
            return bool(vm_flags[feature])

        # Level 2: User override
        if user_flags and feature in user_flags:
            return bool(user_flags[feature])

        # Level 1: Global setting
        if global_flags and feature in global_flags:
            return bool(global_flags[feature])

        # Default
        return FEATURE_DEFAULTS.get(feature, True)

    @staticmethod
    def resolve_all_flags(
        global_flags: dict | None = None,
        user_flags: dict | None = None,
        vm_flags: dict | None = None,
    ) -> dict[str, bool]:
        """Resolve all feature flags with their sources."""
        result = {}
        for feature in FEATURE_DEFAULTS:
            result[feature] = FeatureFlagService.resolve_flag(
                feature, global_flags, user_flags, vm_flags
            )
        return result

    @staticmethod
    def get_flag_source(
        feature: str,
        global_flags: dict | None = None,
        user_flags: dict | None = None,
        vm_flags: dict | None = None,
    ) -> str:
        """Get which level sets the flag value (for UI display)."""
        if vm_flags and feature in vm_flags:
            return "vm"
        if user_flags and feature in user_flags:
            return "user"
        if global_flags and feature in global_flags:
            return "global"
        return "default"

    @staticmethod
    async def check_feature(
        session: AsyncSession,
        feature: str,
        user=None,
        vm=None,
    ) -> bool:
        """Convenience method to check a single feature."""
        global_flags = await FeatureFlagService.get_global_flags(session)
        user_flags = user.feature_flags if user else None
        vm_flags = vm.feature_flags if vm else None
        return FeatureFlagService.resolve_flag(feature, global_flags, user_flags, vm_flags)
```

### Step 2: Create Feature Flag Schemas

File: `/home/portal/backend/app/schemas/feature-flag-schema.py`

```python
from pydantic import BaseModel

class FeatureFlagsUpdate(BaseModel):
    cloudflare_tunnel_enabled: bool | None = None
    public_ip_enabled: bool | None = None
    email_notifications_enabled: bool | None = None
    telegram_notifications_enabled: bool | None = None

class FeatureFlagResolution(BaseModel):
    """Resolved feature flag with source info."""
    feature: str
    value: bool
    source: str  # "default" | "global" | "user" | "vm"

class AllFlagsResponse(BaseModel):
    flags: dict[str, bool]
    sources: dict[str, str]
```

### Step 3: Create Admin Feature Flags API

File: `/home/portal/backend/app/api/admin-feature-flags-router.py`

```python
router = APIRouter(prefix="/admin/feature-flags", tags=["Admin Feature Flags"])

@router.get("/global")
async def get_global_flags(session: AsyncSession = Depends(...)):
    """Get global feature flag settings."""
    flags = await FeatureFlagService.get_global_flags(session)
    return {"flags": {**FEATURE_DEFAULTS, **flags}}

@router.put("/global")
async def update_global_flags(
    data: FeatureFlagsUpdate,
    session: AsyncSession = Depends(...),
):
    """Update global feature flags."""
    current = await FeatureFlagService.get_global_flags(session)
    updated = {**current}
    for key, value in data.dict(exclude_none=True).items():
        updated[key] = value
    await FeatureFlagService.set_global_flags(session, updated)
    return {"flags": updated}

@router.get("/users/{user_id}")
async def get_user_flags(user_id: int, ...):
    """Get user-level feature flags."""

@router.put("/users/{user_id}")
async def update_user_flags(user_id: int, data: FeatureFlagsUpdate, ...):
    """Update user-level feature flags."""
```

### Step 4: Add VM Feature Flags Endpoint

File: `/home/portal/backend/app/api/vm_routes.py`

```python
@router.get("/{vm_id}/feature-flags")
async def get_vm_flags(vm_id: int, current_user: User = Depends(...)):
    """Get resolved feature flags for a VM."""
    vm = await get_vm_or_404(session, vm_id, current_user)
    global_flags = await FeatureFlagService.get_global_flags(session)
    user_flags = current_user.feature_flags

    flags = FeatureFlagService.resolve_all_flags(global_flags, user_flags, vm.feature_flags)
    sources = {
        f: FeatureFlagService.get_flag_source(f, global_flags, user_flags, vm.feature_flags)
        for f in FEATURE_DEFAULTS
    }
    return {"flags": flags, "sources": sources}

@router.put("/{vm_id}/feature-flags")
async def update_vm_flags(
    vm_id: int,
    data: FeatureFlagsUpdate,
    current_user: User = Depends(...),
):
    """Update VM-level feature flags."""
    vm = await get_vm_or_404(session, vm_id, current_user)
    current = vm.feature_flags or {}
    for key, value in data.dict(exclude_none=True).items():
        if value is None:
            current.pop(key, None)  # Remove override
        else:
            current[key] = value
    vm.feature_flags = current
    await session.commit()
    return {"feature_flags": vm.feature_flags}
```

### Step 5: Integrate Feature Checks into Business Logic

Update relevant services to check feature flags:

```python
# VM Creation - check cloudflare_tunnel_enabled
async def create_vm(...):
    if request.enable_ssh_domain:
        can_use_tunnel = await FeatureFlagService.check_feature(
            session, "cloudflare_tunnel_enabled", user=current_user
        )
        if not can_use_tunnel:
            raise HTTPException(403, "Cloudflare Tunnel feature is disabled")

# IP Assignment - check public_ip_enabled
async def assign_public_ip(...):
    can_use_public_ip = await FeatureFlagService.check_feature(
        session, "public_ip_enabled", user=current_user, vm=vm
    )
    if not can_use_public_ip:
        raise HTTPException(403, "Public IP feature is disabled")

# Notifications - check email/telegram enabled
async def notify_vm_ready(...):
    email_enabled = await FeatureFlagService.check_feature(
        session, "email_notifications_enabled", user=user
    )
    telegram_enabled = await FeatureFlagService.check_feature(
        session, "telegram_notifications_enabled", user=user
    )
```

### Step 6: Create Admin Feature Flags UI

File: `/home/portal/frontend/src/pages/admin/global-feature-flags-settings-page.tsx`

```tsx
// Global toggles with descriptions
const features = [
  {
    key: 'cloudflare_tunnel_enabled',
    label: 'Cloudflare Tunnel',
    description: 'Cho phép tạo SSH subdomain qua Cloudflare Tunnel',
  },
  {
    key: 'public_ip_enabled',
    label: 'Public IP',
    description: 'Cho phép gán và giữ lại IP public',
  },
  // ...
];

// UI: List of Switch toggles
{features.map(f => (
  <FormControlLabel
    key={f.key}
    control={
      <Switch
        checked={flags[f.key]}
        onChange={(e) => updateFlag(f.key, e.target.checked)}
      />
    }
    label={
      <Box>
        <Typography>{f.label}</Typography>
        <Typography variant="caption" color="textSecondary">
          {f.description}
        </Typography>
      </Box>
    }
  />
))}
```

### Step 7: Add User Feature Flags to Admin User Edit

File: `/home/portal/frontend/src/pages/admin/user-management-edit-page.tsx`

Add feature flags section showing:
- Current value (resolved)
- Source (global/user/default)
- Override toggle

### Step 8: Add VM Feature Flags to VM Settings

File: `/home/portal/frontend/src/pages/vm-detail-settings-page.tsx`

Add feature flags tab/section:
- Show resolved values with source indicators
- Allow user to override (if permitted)

## Todo List

- [x] Create FeatureFlagService with resolution logic
- [x] Create Pydantic schemas for feature flags
- [x] Add admin API for global flags
- [x] Add admin API for user flags
- [x] Add VM feature flags endpoint
- [x] Integrate feature checks into VM creation
- [x] Integrate feature checks into IP assignment
- [x] Integrate feature checks into notifications
- [x] Create admin global flags UI
- [x] Add user flags to admin user edit
- [x] Add VM flags to VM settings page
- [ ] Test 3-level resolution

## Success Criteria

- [ ] Admin can set global feature flags
- [ ] Admin can override flags per user
- [ ] User can override flags per VM (where allowed)
- [ ] Resolution follows VM > User > Global > Default
- [ ] UI shows which level sets the value
- [ ] Disabled features properly block actions
- [ ] Removing override inherits from parent level

## Related Code Files

| Action | File |
|--------|------|
| Create | `/home/portal/backend/app/services/feature-flag-resolution-service.py` |
| Create | `/home/portal/backend/app/schemas/feature-flag-schema.py` |
| Create | `/home/portal/backend/app/api/admin-feature-flags-router.py` |
| Modify | `/home/portal/backend/app/api/vm_routes.py` |
| Modify | `/home/portal/backend/app/main.py` (register router) |
| Create | `/home/portal/frontend/src/pages/admin/global-feature-flags-settings-page.tsx` |
| Modify | `/home/portal/frontend/src/pages/admin/` (user edit) |
| Modify | `/home/portal/frontend/src/pages/` (VM settings) |

## Security Considerations

- Only admin can set global and user-level flags
- Users can only modify VM flags for their own VMs
- Feature checks must be server-side (don't trust client)

## UI/UX Considerations

- Show inherited value when not overridden
- Use visual indicator (icon/color) for source level
- "Reset to inherited" button to remove override
- Tooltips explaining each feature

## Completion

This phase completes the VM Portal Network & Email Features implementation. After all phases:

1. Network bridges configurable per Proxmox server
2. VM creation supports bridge selection and VLANs
3. Users can manage their public IP pool
4. Dual-provider email notifications working
5. 3-level feature toggles controlling all features
