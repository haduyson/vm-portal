# Phase 1: Database Migrations - Network Bridges, IP Pool, Email Fields

## Context Links

- [Main Plan](./plan.md)
- [Brainstorm](../reports/brainstorm-260131-0747-vm-portal-network-email-features.md)
- Existing models: `/home/portal/backend/app/models/`

## Overview

| Priority | P1 - Foundation |
|----------|-----------------|
| Status | pending |
| Effort | 4h |

Create database schema for network bridges, user IP addresses, and extend User/VM models with email and feature flag fields.

## Key Insights

- User model has `telegram_chat_id` but no email field
- VM model has `ip_address` but no network configuration
- ProxmoxServer has no bridge configuration
- System settings uses key-value pattern (good for email config)

## Requirements

### New Tables

1. **network_bridges**: Store available bridges per Proxmox server
2. **user_ip_addresses**: Track user-owned public IPs

### Altered Tables

1. **users**: Add email, notification_preference, feature_flags
2. **virtual_machines**: Add network_bridge_id, vlan_tags, feature_flags

## Architecture

```
┌─────────────────────┐     ┌──────────────────────┐
│  proxmox_servers    │────<│   network_bridges    │
└─────────────────────┘     └──────────────────────┘
                                      │
                                      ▼
┌─────────────────────┐     ┌──────────────────────┐
│      users          │────<│  user_ip_addresses   │
└─────────────────────┘     └──────────────────────┘
         │                            │
         ▼                            ▼
┌─────────────────────┐     (vm_id nullable FK)
│  virtual_machines   │◄────────────────────────────
└─────────────────────┘
```

## Implementation Steps

### Step 1: Create NetworkBridge Model

File: `/home/portal/backend/app/models/network-bridge-model.py`

```python
class NetworkBridge(Base):
    __tablename__ = "network_bridges"

    id = Column(Integer, primary_key=True, index=True)
    proxmox_server_id = Column(Integer, ForeignKey("proxmox_servers.id"), nullable=False)
    bridge_name = Column(String(50), nullable=False)  # vmbr0, vmbr1
    display_name = Column(String(100), nullable=True)
    vlan_min = Column(Integer, nullable=True)  # NULL = no restriction
    vlan_max = Column(Integer, nullable=True)
    is_public_network = Column(Boolean, default=False)
    is_enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint('proxmox_server_id', 'bridge_name', name='uq_server_bridge'),
    )
```

### Step 2: Create UserIpAddress Model

File: `/home/portal/backend/app/models/user-ip-address-model.py`

```python
class UserIpAddress(Base):
    __tablename__ = "user_ip_addresses"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    ip_address = Column(String(45), unique=True, nullable=False)  # IPv4 or IPv6
    network_bridge_id = Column(Integer, ForeignKey("network_bridges.id"), nullable=False)
    vm_id = Column(Integer, ForeignKey("virtual_machines.id"), nullable=True)
    subnet_mask = Column(String(20), default="255.255.255.0")
    gateway = Column(String(45), nullable=True)
    is_retained = Column(Boolean, default=False)
    acquired_at = Column(DateTime, default=datetime.utcnow)
```

### Step 3: Alter User Model

Add to `/home/portal/backend/app/models/user_model.py`:

```python
email = Column(String(255), nullable=True)
notification_preference = Column(String(20), default="telegram")  # telegram|email|both
feature_flags = Column(JSON, nullable=True)  # {"cloudflare_tunnel_enabled": true}
```

### Step 4: Alter VirtualMachine Model

Add to `/home/portal/backend/app/models/virtual_machine_model.py`:

```python
network_bridge_id = Column(Integer, ForeignKey("network_bridges.id"), nullable=True)
vlan_tags = Column(JSON, nullable=True)  # [100] or [10, 20, 30]
feature_flags = Column(JSON, nullable=True)
```

### Step 5: Create Alembic Migration

File: `/home/portal/backend/alembic/versions/XXXXXX_add_network_bridges_ip_pool_email.py`

```python
def upgrade():
    # 1. Create network_bridges table
    op.create_table('network_bridges', ...)

    # 2. Create user_ip_addresses table
    op.create_table('user_ip_addresses', ...)

    # 3. Alter users table
    op.add_column('users', sa.Column('email', sa.String(255), nullable=True))
    op.add_column('users', sa.Column('notification_preference', sa.String(20), server_default='telegram'))
    op.add_column('users', sa.Column('feature_flags', sa.JSON(), nullable=True))

    # 4. Alter virtual_machines table
    op.add_column('virtual_machines', sa.Column('network_bridge_id', sa.Integer(), nullable=True))
    op.add_column('virtual_machines', sa.Column('vlan_tags', sa.JSON(), nullable=True))
    op.add_column('virtual_machines', sa.Column('feature_flags', sa.JSON(), nullable=True))
    op.create_foreign_key(...)

def downgrade():
    # Reverse operations
```

### Step 6: Update Models __init__.py

Export new models from `/home/portal/backend/app/models/__init__.py`

## Todo List

- [ ] Create NetworkBridge model file
- [ ] Create UserIpAddress model file
- [ ] Add email, notification_preference, feature_flags to User model
- [ ] Add network_bridge_id, vlan_tags, feature_flags to VM model
- [ ] Create Alembic migration script
- [ ] Update models/__init__.py
- [ ] Run migration: `alembic upgrade head`
- [ ] Verify tables created in PostgreSQL

## Success Criteria

- [ ] `network_bridges` table exists with correct schema
- [ ] `user_ip_addresses` table exists with unique IP constraint
- [ ] User model has email, notification_preference, feature_flags
- [ ] VM model has network_bridge_id, vlan_tags, feature_flags
- [ ] Foreign keys properly reference parent tables
- [ ] Migration reversible (downgrade works)

## Related Code Files

| Action | File |
|--------|------|
| Create | `/home/portal/backend/app/models/network-bridge-model.py` |
| Create | `/home/portal/backend/app/models/user-ip-address-model.py` |
| Modify | `/home/portal/backend/app/models/user_model.py` |
| Modify | `/home/portal/backend/app/models/virtual_machine_model.py` |
| Modify | `/home/portal/backend/app/models/__init__.py` |
| Create | `/home/portal/backend/alembic/versions/XXXXXX_add_network_email_features.py` |

## Next Phase

[Phase 2: Proxmox Network Integration](./phase-02-proxmox-network-api-bridge-discovery-admin-ui.md)
