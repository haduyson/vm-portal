---
title: "VM Portal Network & Email Features"
description: "Add VLAN/bridge config, IP pool management, email notifications, and feature toggles"
status: pending
priority: P1
effort: 24h
branch: main
tags: [network, vlan, email, feature-toggles, proxmox]
created: 2026-01-31
---

# VM Portal Network & Email Features

## Overview

Extend VM Portal with advanced networking (bridge/VLAN configuration, IP pool management), dual-provider email notifications, and hierarchical feature toggles.

## Research References

- [Proxmox Network VLAN Research](./research/researcher-proxmox-network-vlan.md)
- [Email Providers API Research](./research/researcher-email-providers-api.md)
- [Brainstorm Document](../reports/brainstorm-260131-0747-vm-portal-network-email-features.md)

## Current State Analysis

| Component | Current | Target |
|-----------|---------|--------|
| Network | Hardcoded `vmbr0` | Dynamic bridge selection + VLAN tags |
| IP Management | DHCP only | DHCP + user-owned IP pool |
| Notifications | Telegram only | Telegram + Email (SMTP/API) |
| Feature Control | None | 3-level toggles (Global > User > VM) |

## Phase Summary

| Phase | Description | Effort | Status |
|-------|-------------|--------|--------|
| [Phase 1](./phase-01-database-migrations-network-bridges-ip-pool-email-fields.md) | Database migrations & models | 4h | pending |
| [Phase 2](./phase-02-proxmox-network-api-bridge-discovery-admin-ui.md) | Proxmox network API + Admin UI | 4h | pending |
| [Phase 3](./phase-03-vm-creation-form-network-bridge-vlan-selection.md) | VM creation with network selection | 4h | pending |
| [Phase 4](./phase-04-user-ip-pool-acquire-retain-static-assignment.md) | User IP pool management | 4h | pending |
| [Phase 5](./phase-05-email-service-smtp-api-dual-provider-notifications.md) | Email service (SMTP + API) | 4h | pending |
| [Phase 6](./phase-06-hierarchical-feature-toggles-global-user-vm-level.md) | Hierarchical feature toggles | 4h | pending |

## Key Technical Decisions

1. **VLAN Implementation**: Use vlan-aware bridge approach with `tag` (access) and `trunks` (trunk) parameters
2. **IP Pool**: User-owned IPs via DHCP acquisition; static assignment via cloud-init `ipconfig0`
3. **Email Provider**: Dual support (aiosmtplib for SMTP, httpx for SendGrid/API)
4. **Feature Toggles**: JSON columns with cascade resolution (VM > User > Global)

## Dependencies

- Proxmox VE 8.2+ (for VLAN trunking support)
- Python: `aiosmtplib>=3.0.0`, `httpx>=0.24.0`
- No new frontend dependencies (MUI v5 sufficient)

## Risk Assessment

| Risk | Mitigation |
|------|------------|
| VLAN misconfiguration | Validate ranges; test in isolated environment |
| IP conflicts | Unique constraint; sync with DHCP |
| Email deliverability | Dual provider fallback; rate limiting |
| Feature toggle complexity | Clear UI showing inherited values |

## Success Criteria

- [ ] Admin can configure bridges/VLANs per Proxmox server
- [ ] Users can select network when creating VM
- [ ] VLAN trunk mode works with multiple VLANs
- [ ] User IP pool: acquire, retain, reuse
- [ ] Email sends via SMTP and API providers
- [ ] Feature toggles cascade correctly (3 levels)
- [ ] Notification preference (Telegram/Email/Both) works

## Validation Summary

**Validated:** 2026-01-31
**Questions asked:** 5

### Confirmed Decisions

| Decision | User Choice |
|----------|-------------|
| Proxmox Version | 8.2+ (full VLAN trunk support) |
| IP Cleanup on User Delete | Return to DHCP pool (delete ownership records) |
| Email Verification | Required - send verify link before notifications |
| Email Provider | User configurable (admin chooses in settings) |
| Default Bridge | Auto-discover first bridge from Proxmox API |

### Action Items

- [ ] Phase 1: Add `is_email_verified` column to users table
- [ ] Phase 4: Implement cascade delete for user_ip_addresses on user delete
- [ ] Phase 5: Add email verification flow (token generation, verify endpoint)
- [ ] Phase 2: Implement auto-discover bridge as fallback when no config exists

## Remaining Questions

1. **Rate Limiting**: Max emails/day/user? (Defer to Phase 5)
2. **IP Billing**: Charge for retained public IPs? (Out of scope for now)
