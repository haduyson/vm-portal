# Phase 3: VM Creation Form - Network Bridge & VLAN Selection

## Context Links

- [Main Plan](./plan.md)
- [Phase 2: Bridge Discovery](./phase-02-proxmox-network-api-bridge-discovery-admin-ui.md)
- [Proxmox VLAN Research](./research/researcher-proxmox-network-vlan.md)
- VM Creation: `/home/portal/backend/app/api/` (vm routes)
- Cloud-init: `/home/portal/backend/app/services/cloud_init_generator.py`

## Overview

| Priority | P1 |
|----------|-----|
| Status | pending |
| Effort | 4h |
| Depends on | Phase 1, Phase 2 |

Update VM creation flow to support network bridge selection and VLAN tagging (access + trunk modes).

## Key Insights

- Current: hardcoded `net0="virtio,bridge=vmbr0"` in proxmox_client.py:189
- Current: `ipconfig0="ip=dhcp"` only supports DHCP
- VLAN access mode: `net0=virtio,bridge=vmbr0,tag=100`
- VLAN trunk mode: `net0=virtio,bridge=vmbr0,trunks=10;20;30`
- Proxmox 8.2+ required for `trunks` parameter

## Requirements

### Functional

1. VM create form shows bridge dropdown (enabled bridges only)
2. Optional VLAN input field (validated against bridge restrictions)
3. Support single VLAN (access) and multiple VLANs (trunk)
4. Backend generates correct `net0` parameter
5. Store network config in VM record

### Non-Functional

- Backward compatible: existing VMs without bridge_id still work
- Default to first enabled bridge if none selected

## Architecture

```
┌──────────────────────┐
│  VM Create Form      │
│  - Bridge dropdown   │
│  - VLAN input        │
└──────────────────────┘
           │
           ▼
┌──────────────────────┐
│  POST /api/vms/      │
│  {network_bridge_id, │
│   vlan_tags: [100]}  │
└──────────────────────┘
           │
           ▼
┌──────────────────────┐
│  VMService           │
│  - Validate bridge   │
│  - Generate net0     │
└──────────────────────┘
           │
           ▼
┌──────────────────────┐
│  ProxmoxService      │
│  net0=virtio,        │
│  bridge=vmbr1,tag=100│
└──────────────────────┘
```

## Implementation Steps

### Step 1: Update VM Create Schema

File: `/home/portal/backend/app/schemas/virtual_machine_schema.py`

```python
class VMCreateRequest(BaseModel):
    name: str
    cores: int
    memory_mb: int
    disk_gb: int
    os_type: str
    proxmox_server_id: int
    storage: str
    # New fields
    network_bridge_id: int | None = None  # Optional, uses default if None
    vlan_tags: list[int] | None = None    # [100] or [10, 20, 30]

    @validator('vlan_tags')
    def validate_vlan_tags(cls, v):
        if v:
            for tag in v:
                if not 1 <= tag <= 4094:
                    raise ValueError(f'VLAN tag must be 1-4094, got {tag}')
        return v
```

### Step 2: Create Network Config Generator

File: `/home/portal/backend/app/services/network-config-generator.py`

```python
def generate_net0_config(
    bridge_name: str,
    vlan_tags: list[int] | None = None,
    mac_address: str | None = None
) -> str:
    """Generate Proxmox net0 parameter string."""
    base = f"virtio,bridge={bridge_name}"

    if mac_address:
        base = f"virtio={mac_address},bridge={bridge_name}"

    if not vlan_tags:
        return base

    if len(vlan_tags) == 1:
        # Access mode - single VLAN
        return f"{base},tag={vlan_tags[0]}"

    # Trunk mode - multiple VLANs
    trunks = ";".join(map(str, vlan_tags))
    return f"{base},trunks={trunks}"
```

### Step 3: Update ProxmoxService.create_vm

File: `/home/portal/backend/app/services/proxmox_client.py`

Modify `create_vm` method to accept `net0` parameter instead of hardcoding:

```python
async def create_vm(
    self,
    vmid: int,
    name: str,
    cores: int,
    memory_mb: int,
    disk_gb: int,
    storage: str,
    iso: str,
    iso_storage: str = None,
    net0: str = "virtio,bridge=vmbr0",  # New parameter with default
) -> Dict:
    """Create a new VM in Proxmox."""
    # ... existing code ...
    return self.proxmox.nodes(self.node).qemu.post(
        # ... existing params ...
        net0=net0,  # Use parameter instead of hardcoded
        # ...
    )
```

### Step 4: Update VM Creation API

File: `/home/portal/backend/app/api/vm_routes.py` (or equivalent)

```python
@router.post("/")
async def create_vm(request: VMCreateRequest, ...):
    # 1. Validate network_bridge_id exists and is enabled
    bridge = None
    if request.network_bridge_id:
        bridge = await NetworkBridgeService.get_bridge(session, request.network_bridge_id)
        if not bridge or not bridge.is_enabled:
            raise HTTPException(400, "Invalid or disabled network bridge")

        # Validate VLAN tags within bridge restrictions
        if request.vlan_tags and bridge.vlan_min and bridge.vlan_max:
            for tag in request.vlan_tags:
                if not bridge.vlan_min <= tag <= bridge.vlan_max:
                    raise HTTPException(400, f"VLAN {tag} outside allowed range")
    else:
        # Use default bridge for server
        bridge = await NetworkBridgeService.get_default_bridge(session, request.proxmox_server_id)

    # 2. Generate net0 config
    net0 = generate_net0_config(bridge.bridge_name, request.vlan_tags)

    # 3. Create VM with net0
    # ... existing creation logic with net0 parameter ...

    # 4. Store network info in VM record
    vm.network_bridge_id = bridge.id
    vm.vlan_tags = request.vlan_tags
```

### Step 5: Add Bridges API for VM Creation Form

File: `/home/portal/backend/app/api/vm_routes.py`

```python
@router.get("/network-options/{server_id}")
async def get_network_options(server_id: int, ...):
    """Get available network bridges for VM creation."""
    bridges = await NetworkBridgeService.get_enabled_bridges(session, server_id)
    return {
        "bridges": [
            {
                "id": b.id,
                "name": b.bridge_name,
                "display_name": b.display_name or b.bridge_name,
                "vlan_min": b.vlan_min,
                "vlan_max": b.vlan_max,
                "is_public_network": b.is_public_network,
            }
            for b in bridges
        ]
    }
```

### Step 6: Update Frontend VM Create Form

File: `/home/portal/frontend/src/pages/vm-create-page.tsx` (or equivalent)

Add to form:
1. Bridge dropdown (load from `/api/vms/network-options/{server_id}`)
2. VLAN input field (show when bridge allows VLANs)
3. Trunk mode toggle (allow multiple VLANs)

```tsx
// State
const [bridges, setBridges] = useState<Bridge[]>([]);
const [selectedBridge, setSelectedBridge] = useState<number | null>(null);
const [vlanTags, setVlanTags] = useState<number[]>([]);
const [isTrunkMode, setIsTrunkMode] = useState(false);

// Fetch bridges when server changes
useEffect(() => {
  if (selectedServer) {
    fetchBridges(selectedServer);
  }
}, [selectedServer]);

// Form fields
<FormControl>
  <InputLabel>Network Bridge</InputLabel>
  <Select value={selectedBridge} onChange={...}>
    {bridges.map(b => (
      <MenuItem key={b.id} value={b.id}>{b.display_name}</MenuItem>
    ))}
  </Select>
</FormControl>

{selectedBridge && (
  <TextField
    label={isTrunkMode ? "VLAN Tags (comma-separated)" : "VLAN Tag"}
    value={vlanTags.join(',')}
    onChange={...}
    helperText={`Allowed: ${bridge.vlan_min}-${bridge.vlan_max}`}
  />
)}
```

## Todo List

- [ ] Update VMCreateRequest schema with network fields
- [ ] Create network-config-generator.py with generate_net0_config()
- [ ] Modify ProxmoxService.create_vm to accept net0 param
- [ ] Update VM creation API with bridge validation
- [ ] Add /api/vms/network-options/{server_id} endpoint
- [ ] Update frontend VM create form with bridge dropdown
- [ ] Add VLAN input with validation feedback
- [ ] Add trunk mode toggle for multiple VLANs
- [ ] Test access mode (single VLAN)
- [ ] Test trunk mode (multiple VLANs)

## Success Criteria

- [ ] VM create form shows enabled bridges from selected server
- [ ] Single VLAN creates VM with `tag=100` parameter
- [ ] Multiple VLANs creates VM with `trunks=10;20;30` parameter
- [ ] VLAN validation enforces bridge restrictions
- [ ] VM record stores network_bridge_id and vlan_tags
- [ ] Existing VMs without bridge config still work
- [ ] Default bridge used when none selected

## Related Code Files

| Action | File |
|--------|------|
| Modify | `/home/portal/backend/app/schemas/virtual_machine_schema.py` |
| Create | `/home/portal/backend/app/services/network-config-generator.py` |
| Modify | `/home/portal/backend/app/services/proxmox_client.py` |
| Modify | `/home/portal/backend/app/api/vm_routes.py` |
| Modify | `/home/portal/frontend/src/pages/` (VM create form) |

## Security Considerations

- Validate bridge belongs to selected Proxmox server
- Validate user has permission to use selected bridge
- Validate VLAN tags within allowed range

## Next Phase

[Phase 4: IP Pool Management](./phase-04-user-ip-pool-acquire-retain-static-assignment.md)
