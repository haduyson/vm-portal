# Proxmox VE Network & VLAN API Research

## Executive Summary
Proxmox VE provides REST API endpoints for network management via `/nodes/{node}/network`. VLAN configuration uses bridge-aware tagging with two implementation patterns: vlan-aware bridges (recommended) and vlan-unaware bridges. Cloud-init integration via `cicustom` parameter enables static IP assignment with netplan v2 format.

---

## 1. Proxmox API Network Endpoints

### Primary Endpoint
```
GET /nodes/{node}/network
```
Returns network interfaces and bridges on specified node. Query parameter: `?type=any_bridge` to filter bridges (though forum reports some API issues with bridge filtering in v8.4.0+).

### Response Structure
- **iface**: Interface name (e.g., `vmbr0`, `eth0`)
- **type**: Interface type (`bridge`, `bond`, `vlan`, `loopback`, `inet`, `inet6`)
- **ipv4**: IP configuration (CIDR format)
- **ipv6**: IPv6 configuration
- **gateway**: Default gateway
- **gateway6**: IPv6 gateway
- **autostart**: Boot behavior

### Workaround for Bridge Discovery
If `/nodes/{node}/network` API has filtering issues, fall back to direct REST API calls or use pvesh command-line tool as root on the node.

---

## 2. VM Network Configuration - VLAN Tagging

### Two-Method Architecture

#### Method A: VLAN-Aware Bridge (Recommended)
Single bridge with native VLAN support. Each VM NIC tagged individually.

**Bridge Configuration** (`/etc/network/interfaces`):
```
auto vmbr0
iface vmbr0 inet manual
    bridge-ports eth0
    bridge-stp off
    bridge-fd 0
    bridge-vlan-aware yes
    bridge-vids 2-4094
```

**VM Network Config** (in Proxmox VM config):
```
net0: virtio=XX:XX:XX:XX:XX:XX,bridge=vmbr0,tag=100
```
- `tag=100`: Single VLAN assignment
- `trunks=10-20;30`: Multiple VLAN support (v8.2+)

#### Method B: VLAN-Unaware Bridges
Multiple bridges, each tied to a VLAN interface.

**Host Configuration**:
```
auto vlan100
iface vlan100 inet static
    vlan-raw-device eth0
    address 10.10.100.2/24

auto vmbr100
iface vmbr100 inet static
    bridge-ports vlan100
    address 10.10.100.3/24
```

**VM Config**:
```
net0: virtio=XX:XX:XX:XX:XX:XX,bridge=vmbr100
```

### Key Parameters
- **tag**: Single VLAN ID (1-4094)
- **trunks**: Multiple VLANs (e.g., `10-20;30`)
- **bridge**: Bridge interface name

---

## 3. Cloud-Init Network Configuration v2 (Static IPs)

### Direct Parameter Approach
Proxmox VM config uses standard parameters:
```
ipconfig0: ip=192.168.1.100/24,gw=192.168.1.1
ipconfig0: ip6=fe80::1/64,gw6=2001:db8::1
nameserver: 8.8.8.8 8.8.4.4
searchdomain: example.com
```

### Custom Cloud-Init with Netplan v2
Use `cicustom` parameter for advanced scenarios:

**Format**:
```
cicustom: base64:encoded-network-config
```

**Network Config v2 (YAML)**:
```yaml
version: 2
ethernets:
  eth0:
    dhcp4: false
    addresses:
      - 192.168.1.100/24
    gateway4: 192.168.1.1
    nameservers:
      addresses: [8.8.8.8, 8.8.4.4]
      search: [example.com]
vlans:
  vlan100:
    id: 100
    link: eth0
    addresses:
      - 10.10.100.50/24
    gateway4: 10.10.100.1
```

### API Call Example
```bash
curl -X PUT https://proxmox:8006/api2/json/nodes/pvenode/qemu/100/config \
  -H "CSRFPreventionToken: <token>" \
  --data 'cicustom=base64:<encoded-yaml>'
```

---

## 4. Best Practices for VLAN Implementation

1. **Bridge Design**
   - Use vlan-aware bridge for most deployments (simpler, fewer bridges)
   - Use vlan-unaware for legacy systems or complex isolation needs

2. **Physical Network**
   - Configure switch port as TRUNK (not access mode)
   - Allow all required VLAN IDs to trunk
   - Verify VLAN 1 (default) handling on switch

3. **VM Configuration**
   - Always specify explicit VLAN tag; don't rely on defaults
   - For multi-VLAN VMs, use trunks parameter (Proxmox 8.2+)
   - Validate cloud-init network config in test VMs first

4. **API Integration**
   - Use `/nodes/{node}/network` to discover available bridges
   - Validate bridge vlan-aware flag before assigning tag values
   - Handle API pagination if many interfaces present

5. **Testing**
   - Clone test VM on target VLAN
   - Verify both ingress and egress traffic
   - Test with cloud-init custom configs before production deployment

---

## Known Limitations

- `/nodes/{node}/network` bridge filtering (`?type=any_bridge`) may not work reliably in Proxmox v8.4.0+
- Multiple VLAN trunking (`trunks` parameter) requires Proxmox 8.2+
- Cloud-init v2 netplan config requires Ubuntu 18.04+ or compatible systems

---

## References
- [Proxmox VE API Documentation](https://pve.proxmox.com/wiki/Proxmox_VE_API)
- [Proxmox Network Configuration](https://pve.proxmox.com/wiki/Network_Configuration)
- [Cloud-Init Support](https://pve.proxmox.com/wiki/Cloud-Init_Support)
- [Forum: API Network Bridges Issue](https://forum.proxmox.com/threads/api-nodes-node-network-endpoint-wont-return-bridges.169381/)
- [Certified Geek: Proxmox VLAN Trunking](https://certifiedgeek.weebly.com/blog/proxmox-and-tagged-vlans)
