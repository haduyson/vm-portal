# Async Email Sending Research: Dual Provider Support

## 1. aiosmtplib - Async SMTP Library

**Overview:** Pure asyncio SMTP client for non-blocking email delivery. Requires Python 3.10+.

**Key Features:**
- Full SMTP protocol support (STARTTLS, AUTH)
- Connection pooling capability
- Exception handling for failed sends
- No external service dependencies (self-hosted SMTP)

**Code Pattern:**
```python
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

async def send_smtp(to_email, subject, html, text):
    async with aiosmtplib.SMTP(hostname='smtp.example.com', port=587) as smtp:
        await smtp.login('user@example.com', 'password')
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = 'sender@example.com'
        msg['To'] = to_email
        msg.attach(MIMEText(text, 'plain'))
        msg.attach(MIMEText(html, 'html'))
        await smtp.send_message(msg)
```

**Pros:** No API keys, self-hosted control, low latency
**Cons:** Requires SMTP server management, no delivery analytics

---

## 2. SendGrid API v3 - HTTP-Based Service

**Overview:** RESTful API for transactional email. Managed service with analytics/deliverability.

**Key Features:**
- HTTP-based (works with any HTTP client)
- Built-in template support
- Delivery tracking & analytics
- High deliverability infrastructure
- Supports async/concurrent sending

**Code Pattern (httpx async):**
```python
import httpx
import json

async def send_sendgrid(to_email, subject, html, text):
    async with httpx.AsyncClient() as client:
        payload = {
            "personalizations": [{"to": [{"email": to_email}]}],
            "from": {"email": "sender@example.com"},
            "subject": subject,
            "content": [
                {"type": "text/plain", "value": text},
                {"type": "text/html", "value": html}
            ]
        }
        response = await client.post(
            'https://api.sendgrid.com/v3/mail/send',
            json=payload,
            headers={'Authorization': f'Bearer {SENDGRID_API_KEY}'}
        )
        return response.status_code == 202
```

**Pros:** Managed service, high deliverability, analytics, templates
**Cons:** API rate limits, costs per send, vendor lock-in

---

## 3. Mailgun/Resend API Patterns

**Overview:** Similar HTTP-based alternatives. Resend optimized for developers, Mailgun for enterprise.

**Dual-Provider Strategy:**
- Use feature flags (LaunchDarkly) to switch providers
- Enable dual-send during migration (3-7 days)
- Monitor bounce/complaint rates before cutover
- Fallback pattern: Provider A → Provider B on failure

**Code Pattern (Fallback):**
```python
async def send_email_with_fallback(to_email, subject, html, text):
    try:
        return await send_sendgrid(to_email, subject, html, text)
    except (httpx.HTTPError, asyncio.TimeoutError):
        return await send_smtp(to_email, subject, html, text)
```

---

## 4. Email Template Best Practices

**Multipart MIME Format:**
All modern email providers expect multipart/alternative with plain text + HTML.

**Order Matters:** Plain text first, HTML last (RFC 1341 preference ordering)

**Benefits:**
- **Deliverability:** Spam filters prefer multipart over HTML-only (+20% inbox placement)
- **Accessibility:** Works on watches, voice assistants, text-only clients
- **Security:** Reduces spam filter flags

**Plain Text Guidelines:**
- Concise, short sentences
- Line breaks between paragraphs (readability)
- URLs on separate lines (clickability)
- Max 60-72 chars per line (mobile clients)

**MIME Structure:**
```
multipart/alternative
├── text/plain: Plain text version
└── text/html: HTML version (with inline CSS)
```

---

## 5. Implementation Architecture Recommendation

**Dual-Provider Pattern:**
1. Abstract email service interface (strategy pattern)
2. Provider 1: SendGrid (primary - managed, analytics)
3. Provider 2: aiosmtplib (fallback - self-hosted SMTP)
4. Queue-based async handling with retry logic
5. Template abstraction layer (HTML + plain text generation)

**Advantages:**
- Redundancy: SMTP fallback if API fails
- Cost control: SMTP for low-volume, SendGrid for campaigns
- Independence: Not locked to single vendor
- Analytics: SendGrid events + fallback logging

---

## Key Dependencies

- `aiosmtplib>=3.0.0` - Async SMTP
- `sendgrid>=6.10.0` - SendGrid API
- `httpx>=0.24.0` - Async HTTP (if using Resend/Mailgun)
- `jinja2>=3.1.0` - Template rendering

---

## Sources

- [aiosmtplib Documentation](https://aiosmtplib.readthedocs.io/)
- [SendGrid Python Library](https://github.com/sendgrid/sendgrid-python)
- [SendGrid Async Send Guide](https://github.com/sendgrid/sendgrid-python/blob/main/use_cases/asynchronous_mail_send.md)
- [Multipart MIME Best Practices](https://gist.github.com/tylermakin/d820f65eb3c9dd98d58721c7fb1939a8)
- [Mailgun vs Resend Comparison](https://www.mailgun.com/compare/mailgun-vs-resend/)
- [Email Provider Fallback Patterns](https://knock.app/blog/the-top-transactional-email-services-for-developers)
