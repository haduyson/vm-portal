# Brainstorm: VM Portal Network & Email Features

**Date:** 2026-01-31 | **Status:** Complete

---

## Problem Statement

Mở rộng VM Portal với 6 tính năng mới:
1. Cấu hình bridge/VLAN trong Proxmox Server settings
2. Cho phép admin chọn network khi tạo VM
3. Hỗ trợ VLAN tag (trunk mode)
4. Auto gắn IP public hoặc chọn từ user's IP pool
5. Gửi thông tin qua Email (song song với Telegram)
6. Feature toggles cho Cloudflare Tunnel & IP Public

---

## Requirements Clarified

| Feature | Decision |
|---------|----------|
| Bridge/VLAN | Unlimited - đọc trực tiếp từ Proxmox API |
| VLAN Mode | Trunk support - VM có thể nhận nhiều VLAN |
| IP Source | DHCP auto, IP thuộc về user sau khi VM nhận |
| IP Ownership | User giữ IP khi xóa VM, chọn lại khi tạo VM mới |
| Email Provider | Cả SMTP và Transactional API |
| Email Events | VM ready, VM error, Password reset, Account events |
| Toggle Level | 3 cấp: Global > User > VM với allow override |

---

## Architecture Analysis

### Current State
```
ProxmoxServer:
  - host, port, token, node
  - cloud_init_template_vmid
  - excluded_storages
  - reserve_cpu/ram/disk_percent

VirtualMachine:
  - net0="virtio,bridge=vmbr0" (hardcoded)
  - ipconfig0="ip=dhcp"
  - No VLAN support
  - No IP ownership

Notifications:
  - Telegram only
  - telegram_chat_id per user
```

### Target State
```
ProxmoxServer:
  + available_bridges: JSON (fetched from API, cached)
  + default_bridge: string
  + vlan_ranges: JSON (optional restrictions)

NetworkBridge (new table):
  - proxmox_server_id (FK)
  - bridge_name (vmbr0, vmbr1...)
  - vlan_tag (optional)
  - description
  - is_public (for public IP assignment)

UserIpAddress (new table):
  - user_id (FK)
  - ip_address
  - network_bridge_id (FK)
  - vm_id (FK, nullable - assigned or available)
  - is_retained (user chose to keep when deleting VM)
  - created_at

VirtualMachine:
  + network_bridge_id (FK)
  + vlan_tags: JSON array (for trunk)
  + ip_source: enum (dhcp, static, user_pool)

User:
  + email (optional)
  + notification_preference: enum (telegram, email, both)
  + feature_flags: JSON (per-user overrides)

SystemSettings:
  + email_provider: enum (smtp, sendgrid, mailgun, ses)
  + smtp_host, smtp_port, smtp_user, smtp_password
  + email_api_key, email_from_address
  + email_events: JSON (which events to send)
  + global_feature_flags: JSON

FeatureFlags (new concept):
  - cloudflare_tunnel_enabled: bool
  - public_ip_enabled: bool
  - Level: global → user → vm (cascade with override)
```

---

## Proposed Solutions

### 1. Bridge/VLAN Configuration

**Approach: Dynamic Discovery + Admin Curation**

```python
# ProxmoxService additions
async def get_network_bridges(self) -> list[dict]:
    """Fetch all bridges from Proxmox node"""
    # GET /nodes/{node}/network
    # Filter type="bridge"
    return bridges

# Admin flow:
# 1. Portal fetches bridges from Proxmox API
# 2. Admin marks which bridges are available for VM creation
# 3. Admin can set VLAN restrictions per bridge
```

**Database changes:**
```sql
CREATE TABLE network_bridges (
    id SERIAL PRIMARY KEY,
    proxmox_server_id INT REFERENCES proxmox_servers(id),
    bridge_name VARCHAR(50) NOT NULL,
    display_name VARCHAR(100),
    vlan_min INT DEFAULT NULL,  -- NULL = no restriction
    vlan_max INT DEFAULT NULL,
    is_public_network BOOLEAN DEFAULT FALSE,
    is_enabled BOOLEAN DEFAULT TRUE,
    UNIQUE(proxmox_server_id, bridge_name)
);
```

**Pros:**
- Flexible, không hardcode
- Admin control qua UI
- Sync được với Proxmox changes

**Cons:**
- Cần cache invalidation khi Proxmox config thay đổi

---

### 2. Network Selection in VM Creation

**Approach: Dropdown + VLAN Input**

```typescript
// VM Create Form additions
interface VMCreateRequest {
  // existing fields...
  network_bridge_id: number;       // Required
  vlan_tags?: number[];            // Optional, for trunk
  ip_source: 'dhcp' | 'user_pool'; // Default: dhcp
  selected_ip_id?: number;         // If ip_source = user_pool
}
```

**UI Flow:**
1. User chọn Proxmox Server → load available bridges
2. User chọn Bridge → show VLAN input nếu bridge cho phép
3. User chọn IP source:
   - DHCP (default): VM tự lấy IP
   - User Pool: Show dropdown IPs available của user

**Backend validation:**
- Check bridge exists & enabled
- Check VLAN trong allowed range
- Check IP belongs to user & available

---

### 3. VLAN Trunk Support

**Approach: Multi-VLAN Configuration**

```python
# Cloud-init network config cho trunk
def generate_network_config(bridge: str, vlan_tags: list[int]) -> str:
    if not vlan_tags:
        # Simple bridge, no VLAN
        return f"net0=virtio,bridge={bridge}"

    if len(vlan_tags) == 1:
        # Access mode - single VLAN
        return f"net0=virtio,bridge={bridge},tag={vlan_tags[0]}"

    # Trunk mode - multiple VLANs
    # Proxmox uses trunks parameter
    trunks = ";".join(map(str, vlan_tags))
    return f"net0=virtio,bridge={bridge},trunks={trunks}"
```

**Note:** Proxmox hỗ trợ `trunks` parameter cho VLAN trunking.

---

### 4. IP Public Management

**Approach: User-Owned IP Pool**

```sql
CREATE TABLE user_ip_addresses (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    ip_address INET NOT NULL,
    network_bridge_id INT REFERENCES network_bridges(id),
    vm_id INT REFERENCES virtual_machines(id) NULL,
    subnet_mask VARCHAR(20) DEFAULT '255.255.255.0',
    gateway INET,
    is_retained BOOLEAN DEFAULT FALSE,
    acquired_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(ip_address)
);
```

**Flow:**

```
VM Creation với DHCP:
1. VM boots → gets IP from DHCP
2. Portal detects IP via guest agent
3. If bridge.is_public_network:
   - Create user_ip_addresses record (vm_id = this VM)
4. User now "owns" this IP

VM Deletion:
1. Prompt: "Giữ lại IP public?"
   - Yes: Set vm_id=NULL, is_retained=TRUE
   - No: Delete record, IP returns to DHCP pool

New VM Creation:
1. If user has available IPs (vm_id=NULL):
   - Show dropdown to select
   - Cloud-init với static IP config
2. Else: Use DHCP
```

**Cloud-init static IP:**
```yaml
network:
  version: 2
  ethernets:
    eth0:
      addresses:
        - 103.45.67.89/24
      gateway4: 103.45.67.1
      nameservers:
        addresses: [8.8.8.8, 8.8.4.4]
```

---

### 5. Email Notifications

**Approach: Dual Provider Support (SMTP + API)**

```python
# email_service.py
class EmailService:
    async def send(self, to: str, subject: str, body: str, html: str = None):
        provider = await self.get_provider()

        if provider == "smtp":
            return await self._send_smtp(to, subject, body, html)
        elif provider in ("sendgrid", "mailgun", "ses", "resend"):
            return await self._send_api(to, subject, body, html)

    async def _send_smtp(self, ...):
        # aiosmtplib implementation

    async def _send_api(self, ...):
        # httpx calls to respective APIs
```

**Database additions:**
```sql
ALTER TABLE users ADD COLUMN email VARCHAR(255);
ALTER TABLE users ADD COLUMN notification_preference
    VARCHAR(20) DEFAULT 'telegram'
    CHECK (notification_preference IN ('telegram', 'email', 'both'));

-- System settings (key-value store)
-- email_provider: smtp | sendgrid | mailgun | ses | resend
-- smtp_host, smtp_port, smtp_user, smtp_password, smtp_use_tls
-- email_api_key, email_from_address, email_from_name
-- email_enabled_events: ["vm_ready", "vm_error", "password_reset", "account"]
```

**Admin UI:**
- Email Provider selection
- SMTP config form (if SMTP selected)
- API key input (if API selected)
- Test email button
- Event toggles

---

### 6. Feature Toggles (3-Level)

**Approach: Hierarchical Flags with Override**

```python
# Feature flag resolution
def get_feature_flag(feature: str, user: User, vm: VM = None) -> bool:
    # Level 1: Global
    global_flags = get_system_setting("global_feature_flags") or {}
    global_value = global_flags.get(feature, True)  # Default ON

    # Level 2: User override
    user_flags = user.feature_flags or {}
    user_value = user_flags.get(feature)

    # Level 3: VM override (if applicable)
    vm_flags = vm.feature_flags if vm else None
    vm_value = vm_flags.get(feature) if vm_flags else None

    # Resolution: Most specific wins (allow override)
    if vm_value is not None:
        return vm_value
    if user_value is not None:
        return user_value
    return global_value
```

**Features to toggle:**
- `cloudflare_tunnel_enabled`: Cho phép cấp subdomain
- `public_ip_enabled`: Cho phép sử dụng public IP
- `email_notifications_enabled`: Gửi email
- `telegram_notifications_enabled`: Gửi Telegram

**UI:**
- Admin → Settings: Global toggles
- Admin → Users → Edit: Per-user toggles
- VM Create Form: Per-VM toggles (only if user/global allows)

---

## Implementation Phases

### Phase 1: Database & Models (Foundation)
- Add network_bridges table
- Add user_ip_addresses table
- Add email & notification fields to users
- Add feature_flags JSON columns
- Alembic migrations

### Phase 2: Proxmox Network Integration
- ProxmoxService.get_network_bridges()
- Admin UI for bridge management
- Bridge sync/refresh mechanism

### Phase 3: VM Creation with Network Selection
- Update VM create form
- Backend validation
- Cloud-init với VLAN config
- VLAN trunk support

### Phase 4: IP Pool Management
- IP detection & ownership assignment
- VM deletion với IP retention option
- IP selection in VM creation
- Static IP cloud-init generation

### Phase 5: Email Service
- EmailService with SMTP & API
- Admin email configuration UI
- Email templates (VM ready, error, password, account)
- User notification preference

### Phase 6: Feature Toggles
- Toggle resolution logic
- Admin UI for global/user toggles
- VM creation form với toggle awareness
- Toggle enforcement in all relevant endpoints

---

## Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| VLAN misconfiguration | Network isolation failure | Validate VLAN ranges, test before deploy |
| IP conflicts | VM unreachable | Unique constraint, DHCP sync |
| Email spam | Reputation damage | Rate limiting, admin approval |
| Toggle complexity | Confusing UX | Clear UI with inherited values shown |
| Proxmox API changes | Bridge sync fails | Version check, graceful fallback |

---

## Success Criteria

- [ ] Admin có thể cấu hình bridges/VLANs per Proxmox server
- [ ] User có thể chọn network khi tạo VM
- [ ] VM trunk mode hoạt động với multiple VLANs
- [ ] User IP pool hoạt động: acquire, retain, reuse
- [ ] Email gửi thành công qua cả SMTP và API
- [ ] Feature toggles cascade đúng 3 cấp
- [ ] Notification preference (Telegram/Email/Both) hoạt động

---

## Unresolved Questions

1. **IP Cleanup:** Khi user bị xóa, IPs của họ xử lý thế nào? (Return to pool? Admin reassign?)
2. **VLAN Discovery:** Có cần tự động phát hiện VLANs từ switch hay admin config thủ công?
3. **Email Verification:** Có cần verify email trước khi gửi notifications?
4. **Rate Limiting:** Giới hạn gửi email/ngày/user là bao nhiêu?
5. **IP Billing:** Có tính phí IP public không? Nếu có, cần thêm billing module.

---

## Recommendation

**Proceed with phased implementation.** Đề xuất ưu tiên:

1. **Phase 1-2 trước:** Foundation + Network - cần thiết nhất cho multi-network
2. **Phase 5 song song:** Email - độc lập, có thể làm parallel
3. **Phase 3-4:** VM creation updates - phụ thuộc Phase 1-2
4. **Phase 6 cuối:** Feature toggles - polish, không blocking

Estimated effort: Medium-High complexity, recommend 2-3 sprints.
