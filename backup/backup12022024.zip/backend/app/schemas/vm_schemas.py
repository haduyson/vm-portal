import re
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator


class VMCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)

    @field_validator("name")
    @classmethod
    def validate_dns_name(cls, v: str) -> str:
        """SEC-021: Strict DNS hostname validation."""
        v = v.strip().lower()
        # Must start with letter, contain only alphanumeric and single hyphens
        # Cannot end with hyphen or have consecutive hyphens
        if not re.match(r'^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$', v):
            raise ValueError(
                "Tên VM phải bắt đầu bằng chữ cái, chỉ chứa chữ thường, số và dấu gạch ngang đơn (VD: my-vm-01)"
            )
        if len(v) > 63:  # DNS label limit
            raise ValueError("Tên VM không được quá 63 ký tự")
        return v
    cores: int = Field(..., ge=1, le=16)
    memory_mb: int = Field(..., ge=512, le=32768)
    disk_gb: int = Field(..., ge=10, le=500)
    os_type: str = "ubuntu-24.04"
    server_id: Optional[int] = None
    storage: Optional[str] = None
    ssh_subdomain: Optional[str] = None
    domain_id: Optional[int] = None
    # Network config
    network_bridge_id: Optional[int] = None  # Uses default bridge if None
    vlan_tags: Optional[List[int]] = None  # Single VLAN or multiple (trunk)
    # Static IP from user's pool
    ip_pool_id: Optional[int] = None  # ID of UserIpAddress to use for static IP

    @field_validator("vlan_tags")
    @classmethod
    def validate_vlan_tags(cls, v: Optional[List[int]]) -> Optional[List[int]]:
        if v:
            for tag in v:
                if not 1 <= tag <= 4094:
                    raise ValueError(f"VLAN tag phải từ 1-4094, nhận được {tag}")
        return v


class VMResponse(BaseModel):
    id: int
    user_id: int
    proxmox_server_id: Optional[int] = None
    network_bridge_id: Optional[int] = None
    vmid: int
    name: str
    cores: int
    memory_mb: int
    disk_gb: int
    os_type: str
    status: str
    ip_address: Optional[str]
    ssh_domain: Optional[str]
    web_domain: Optional[str]
    ssh_username: Optional[str]
    ssh_password: Optional[str]
    proxmox_node: str
    storage: str
    vlan_tags: Optional[List[int]] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class VMListResponse(BaseModel):
    total: int
    vms: List[VMResponse]


class VMResourceResponse(BaseModel):
    cpu_percent: float
    memory_used_mb: float
    memory_total_mb: float
    disk_used_gb: float
    disk_total_gb: float


class VMResize(BaseModel):
    cores: Optional[int] = Field(None, ge=1, le=16)
    memory_mb: Optional[int] = Field(None, ge=512, le=65536)
    disk_gb: Optional[int] = Field(None, ge=10, le=1000)


class VMCloneRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)


class VMMetricsDataPoint(BaseModel):
    time: float
    cpu: Optional[float] = None
    mem: Optional[float] = None
    maxmem: Optional[float] = None
    netin: Optional[float] = None
    netout: Optional[float] = None
    disk: Optional[float] = None
    maxdisk: Optional[float] = None


class VMMetricsResponse(BaseModel):
    timeframe: str
    data: List[VMMetricsDataPoint]


class VMConsoleResponse(BaseModel):
    ticket: str
    port: int
    node: str
    vmid: int


class VMResetPassword(BaseModel):
    new_password: str = Field(..., min_length=6, max_length=128)
